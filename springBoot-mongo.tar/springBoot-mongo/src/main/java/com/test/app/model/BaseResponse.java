package com.test.app.model;

import org.apache.commons.lang.StringUtils;

import com.test.app.constants.ResponseCode;


/**
 * Created by 44022710 on 2017/5/23.
 */
public class BaseResponse<T> {
    private String respCode;
    private String message;
    private T      responseBody;

    public BaseResponse() {

    }

    public BaseResponse(final String respCode) {
        this(respCode, null);
    }

    public BaseResponse(final String respCode, final String message) {
        this.respCode = respCode;
        this.message = message;
    }

    public String getRespCode() {
        return this.respCode;
    }

    public void setRespCode(final String respCode) {
        this.respCode = respCode;
        if (ResponseCode.Normal.getCode().equals(respCode)) {
            this.message = "success";
        }
    }

    public void setRespCode(final ResponseCode respCode) {
        this.respCode = respCode.getCode();
        if (ResponseCode.Normal.getCode().equals(respCode.getCode())) {
            this.message = "success";
        } else {
            try {
                this.message = StringUtils.replace(respCode.toString(), "_", " ").toLowerCase();
            } catch (Exception e) {
                this.message = "";
            }
        }
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public T getResponseBody() {
        return this.responseBody;
    }

    public void setResponseBody(final T responseBody) {
        this.responseBody = responseBody;
    }

    @Override
    public String toString() {
        return "BaseResponse{" + "respCode='" + this.respCode + '\'' + ", message='" + this.message + '\'' + ", responseBody="
            + this.responseBody + '}';
    }
}