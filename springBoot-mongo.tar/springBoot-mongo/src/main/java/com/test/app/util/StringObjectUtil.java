/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.test.app.util;

import org.beanio.StreamFactory;
import org.beanio.builder.CsvParserBuilder;
import org.beanio.builder.StreamBuilder;

/**
 * <p>
 * <b> fix length handler </b>
 * </p>
 */
public class StringObjectUtil {

    private static final String CSV_FORMAT = "csv";
    private static CsvParserBuilder PB = new CsvParserBuilder();


    /**
     * <p>
     * <b> convert fix length string to object. </b>
     * </p>
     *
     * @param <T>
     *            class of object
     *
     * @param request
     *            object
     * @return
     */
    public static <T> T unmarshal(final Class<T> clazz, final String operation_request) {
        StreamFactory factory = StreamFactory.newInstance();
        StreamBuilder streamBuilder = new StreamBuilder("builder").format("fixedlength").addRecord(clazz);

        factory.define(streamBuilder);

        T requestObject = (T) factory.createUnmarshaller("builder").unmarshal(operation_request);
        return requestObject;

    }


    public static <T> T unmarshal(final Class<T> clazz, final String operation_request, final String msgFormat,
        final CsvParserBuilder csvParserBuilder) {
        StreamFactory factory = StreamFactory.newInstance();
        StreamBuilder streamBuilder = new StreamBuilder("builder").format(msgFormat).parser(csvParserBuilder).addRecord(clazz);

        factory.define(streamBuilder);

        T requestObject = (T) factory.createUnmarshaller("builder").unmarshal(operation_request);
        return requestObject;
    }

    public static <T> T unmarshalCsv(final Class<T> clazz, final String operation_request) {
        return StringObjectUtil.unmarshal(clazz, operation_request, StringObjectUtil.CSV_FORMAT, StringObjectUtil.PB.delimiter('|'));
    }

    /**
     * <p>
     * <b> onvert object to fix length string </b>
     * </p>
     *
     * @param <T>
     *            class of object
     *
     * @param response
     *            object
     * @return fix length string
     */
    public static <T> String marshal(final Class<T> clazz, final T responseObject) {
        StreamFactory factory = StreamFactory.newInstance();
        StreamBuilder streamBuilder = new StreamBuilder("builder").format("fixedlength").addRecord(clazz);

        factory.define(streamBuilder);

        String messageString = factory.createMarshaller("builder").marshal(responseObject).toString();
        return messageString;

    }


    public static <T> String marshal(final Class<T> clazz, final T responseObject, final String msgFormat,
        final CsvParserBuilder csvParserBuilder) {
        StreamFactory factory = StreamFactory.newInstance();
        StreamBuilder streamBuilder = new StreamBuilder("builder").format(msgFormat).parser(csvParserBuilder).addRecord(clazz);

        factory.define(streamBuilder);

        String messageString = factory.createMarshaller("builder").marshal(responseObject).toString();
        return messageString;
    }

    public static <T> String marshalCsv(final Class<T> clazz, final T responseObject) {
        return StringObjectUtil.marshal(clazz, responseObject, StringObjectUtil.CSV_FORMAT, StringObjectUtil.PB.delimiter('|'));
    }

}
