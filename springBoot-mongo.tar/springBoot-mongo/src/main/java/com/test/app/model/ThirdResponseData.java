package com.test.app.model;

public class ThirdResponseData {
	private long	queryTime;
	private Object	obj;
	private String	bizId;
	private String	appId;

	public String getBizId() {
		return this.bizId;
	}

	public void setBizId(final String bizId) {
		this.bizId = bizId;
	}

	public long getQueryTime() {
		return this.queryTime;
	}

	public void setQueryTime(final long queryTime) {
		this.queryTime = queryTime;
	}

	public Object getObj() {
		return this.obj;
	}

	public void setObj(final Object obj) {
		this.obj = obj;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

}