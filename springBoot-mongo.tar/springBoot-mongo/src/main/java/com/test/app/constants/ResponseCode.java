package com.test.app.constants;

/**
 * @author Shawn.wang
 * @create 2018-4-19 PM3:30:18
 */
public enum ResponseCode {
    SYS_ERROR("Err00001"), 
    TIME_OUT("Err00002"), 
    REST_CLIENT_ISSUE("Err00003"), 
    UNKNOWN_PROTOCOL("Err00004"), 
    UNKNOWN_HOST_EXCEPTION("Err00005"), 
    NOT_FOUND("Err00006"), 
    GENERATE_TOKEN_ERROR("Err00007"), 
    TOKEN_EXPIRED_ERROR("Err00008"), 
    TOKEN_VALIDATION_ERROR("Err00009"), 
    PARAM_ERROR("Err00010"), 
    EMPTY_PARAM_ERROR("Err00012"),
    Normal("00000");


    private String code;

    private ResponseCode(final String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(final String code) {
        this.code = code;
    }
}
