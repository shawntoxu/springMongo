package com.test.app.dao;

import org.springframework.stereotype.Component;

/**
 * @author Shawn.wang
 * @version May 15, 2018 5:50:55 PM
 */
@Component
public class ThirdResponseDataDao extends BaseDao<Object> {

	private Class beanClass;

	protected Class<Object> getEntityClass() {
		if (null != getBeanClass()) {
			return getBeanClass();
		} else {
			return Object.class;
		}
	}

	public Class getBeanClass() {
		return beanClass;
	}

	public void setBeanClass(Class beanClass) {
		this.beanClass = beanClass;
	}

}
