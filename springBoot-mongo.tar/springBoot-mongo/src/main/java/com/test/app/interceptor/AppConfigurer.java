package com.test.app.interceptor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.test.app.constants.ApiURI;

/**
 * @author Shawn.wang
 * @version Jun 12, 2018 3:59:09 PM
 */
@Configuration
public class AppConfigurer extends WebMvcConfigurerAdapter {
	@Bean
	public HandlerInterceptor getMyInterceptor() {
		return new TokenInterceptor();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {

		// registry.addInterceptor(getMyInterceptor())
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.ENTITY_INFO)
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.LOAN_DETAIL)
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.ENTITY_STAKEHOLDER)
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.PG_VERIFY)
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.LOAN_DOCUMENT)
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.LOAN_SUBMIT)
		//
		// .addPathPatterns(ApiURI.API_PREFIX + ApiURI.BUSINESS)
		// .addPathPatterns(ApiURI.API_PREFIX +
		// ApiURI.CONNECTED).addPathPatterns(ApiURI.API_PREFIX + ApiURI.VAT);

		registry.addInterceptor(getMyInterceptor()).addPathPatterns(ApiURI.API_PREFIX + ApiURI.PRIVATE_PREFIX + "/**");

		super.addInterceptors(registry);
	}
}
