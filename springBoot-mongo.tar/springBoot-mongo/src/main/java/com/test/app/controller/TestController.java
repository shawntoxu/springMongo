package com.test.app.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.app.constants.ApiURI;
import com.test.app.constants.ResponseCode;
import com.test.app.dao.ThirdResponseDataDao;
import com.test.app.model.BaseResponse;
import com.test.app.model.CheckAppExistsResponse;
import com.test.app.model.UserClientInfo;
import com.test.app.util.FileUtil;

import eu.bitwalker.useragentutils.Browser;
import eu.bitwalker.useragentutils.OperatingSystem;
import eu.bitwalker.useragentutils.UserAgent;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author Shawn.wang
 * @version May 5, 2018 9:34:57 AM
 */
@Api(tags = "testapi", value = "testapi")
@RestController
@RequestMapping(ApiURI.API_PREFIX)
public class TestController {

	@Autowired
	private ThirdResponseDataDao	thirdResponsDataDao;

	@Autowired
	private FileUtil				fileUtil;

	@RequestMapping(value = "test", method = RequestMethod.GET)
	public void getYinlian(HttpServletRequest request) {
		// testJwtToken();
		// testconfig();

	}

	private void testRbb() {
		// this.rbbCustomerCheckService.RBBCustomerCheck("900024158506143",
		// null, false);

		// Map<String, String> request = new HashMap<String, String>();
		// request.put("tokenId", "t");
		// request.put("referralId", "r");
		// request.put("detailedStatus", "");
		// String result =
		// this.restTemplate.postForObject(this.notifyAwsConfig.getRecivedApi(),
		// request, String.class);

		// Map<String, Object> qmap = new HashMap<String, Object>();
		// qmap.put("bizId", "113");
		// thirdResponsDataDao.setBeanClass(ArchiveIndividualBureau.class);
		// ArchiveIndividualBureau oo = (ArchiveIndividualBureau)
		// thirdResponsDataDao.queryApplicationByKey(qmap);
		// CreditReortResponse result = JSON.parseObject(oo.getObj().toString(),
		// new TypeReference<CreditReortResponse>() {
		// });
		// System.out.println(result.getCreditSummaryCue().getFirstLoancardOpenMonth()
		// + " aaaaaaaaa");
		// ArchiveIndividualBureau archiveIndividualBureau = new
		// ArchiveIndividualBureau();
		// archiveIndividualBureau.setQueryTime(System.currentTimeMillis());
		// archiveIndividualBureau.setBizId("112");
		// archiveIndividualBureau.setObj(oo.getObj().toString());
		// this.thirdResponsDataDao.saveApplicationInfo(archiveIndividualBureau);
	}

	private void testUserClient(HttpServletRequest request) {
		String remoteAddr = null;

		String ip = request.getHeader("X-Real-IP");
		if (ip != null && !"".equals(ip) && !"unknown".equalsIgnoreCase(ip)) {
			int index = ip.indexOf(',');
			if (index != -1) {
				remoteAddr = ip.substring(0, index);
			} else {
				remoteAddr = ip;
			}
		}
		if (null == remoteAddr) {
			remoteAddr = request.getHeader("X-FORWARDED-FOR");
		}
		if (StringUtils.isBlank(remoteAddr)) {
			remoteAddr = request.getRemoteAddr();
		}
		Cookie[] cookies = request.getCookies();
		StringBuffer cookieStr = new StringBuffer();
		if (null != cookies) {
			for (Cookie cookie : cookies) {
				cookieStr.append(cookie.getName()).append(":").append(cookie.getValue());
			}
		}
		System.out.println(cookieStr.toString());
		String userAgent = request.getHeader("User-Agent");
		System.out.println("userAgent == " + userAgent);

		UserAgent ug = UserAgent.parseUserAgentString(userAgent);
		Browser browser = ug.getBrowser();
		System.out.println(browser.getName());
		System.out.println(browser.getVersion(userAgent).getVersion());
		OperatingSystem os = ug.getOperatingSystem();
		System.out.println(os.getName());

		com.test.app.model.UserClientInfo userClientInfo = new UserClientInfo();

		userClientInfo.setIpAddr(remoteAddr);

		// get all cookies ??
		if (null != cookies) {
			for (Cookie cookie : cookies) {
				if (!"JSESSIONID".equalsIgnoreCase(cookie.getName()))
					cookieStr.append(cookie.getName()).append(":").append(cookie.getValue());
			}
		}
		if (cookieStr.toString().length() > 50) {
			userClientInfo.setCookieId(cookieStr.toString().substring(0, 50));
		} else {
			userClientInfo.setCookieId(cookieStr.toString());
		}
		if (null != browser) {
			userClientInfo.setBrowser(browser.getName());
		}
		if (null != browser.getVersion(userAgent) && null != browser.getVersion(userAgent).getVersion()) {
			userClientInfo.setBrowserVersion(browser.getVersion(userAgent).getVersion());
		}
		if (null != ug.getOperatingSystem() && null != ug.getOperatingSystem().getName()) {
			userClientInfo.setOperationSystem(ug.getOperatingSystem().getName());
		}
	}

	@ApiOperation(value = "基本信息chax")
	@RequestMapping(value = ApiURI.EXISTS, method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public BaseResponse<Map<String, Object>> checkApp(@PathVariable("aaa") final String unifiedSocialCreditCode,
			@PathVariable("bbb") final String tokenId) throws Exception {

		CheckAppExistsResponse response = new CheckAppExistsResponse();
		Map<String, Object> responseBody = new HashMap<String, Object>();
		response.setRespCode(ResponseCode.Normal);
		response.setResponseBody(responseBody);

		return response;
	}
}
