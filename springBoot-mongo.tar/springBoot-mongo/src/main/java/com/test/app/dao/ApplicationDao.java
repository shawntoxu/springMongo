package com.test.app.dao;

import org.springframework.stereotype.Component;

import com.test.app.model.LoanApplication;

/**
 * @author Shawn.wang
 * @param <T>
 * @create 2018-4-18 PM2:46:42
 */
@Component
public class ApplicationDao extends BaseDao<LoanApplication> {
	protected Class<LoanApplication> getEntityClass() {
		return LoanApplication.class;
	}

	// public PreScreening getLatestRecords(final String tokenId) {
	// Map<String, Object> map = new HashMap<String, Object>();
	// Map<String, String> orderKey = new HashMap<String, String>();
	// map.put(ApplicationStatus.PRESCREENING_SEARCH_KEY, tokenId);
	// map.put(ApplicationStatus.PRESCREENING_DOCTYPE,
	// ApplicationStatus.DOCTYPE);
	// orderKey.put(ApplicationStatus.PRESCREENING_QUERY_TIME, "DESC");
	//
	// PreScreening preScreenInfo = this.queryApplicationByKeyWithOrder(map,
	// orderKey);
	// return preScreenInfo;
	// }
}
