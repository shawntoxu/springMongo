package com.test.app.constants;

/**
 * @author Shawn.wang
 * @version Jun 11, 2018 5:50:31 PM
 */
public class ApiURI {
	public static final String	API_PREFIX				= "/api/sle/v1";
	public static final String	PUBLIC_PREFIX			= "/pb";
	public static final String	PRIVATE_PREFIX			= "/pv";
	public static final String	INTERNAL_PREFIX			= "/it";

	public static final String	APP_PB					= ApiURI.PUBLIC_PREFIX + "/applications";
	public static final String	APP_PV					= ApiURI.PRIVATE_PREFIX + "/applications";
	public static final String	APP_IT					= ApiURI.INTERNAL_PREFIX + "/applications";

	public static final String	EXISTS					= ApiURI.APP_PB + "/{unifiedSocialCreditCode}/{tokenId}/exists";
	public static final String	EXISTS_AMAZON			= ApiURI.APP_PB + "/{tokenId}/{referralId}/existance";
	public static final String	CHECK_HISTORY			= ApiURI.APP_PB + "/history";
	public static final String	CREATE_APP				= ApiURI.APP_PB + "/loan";

	public static final String	ENTITY_INFO				= ApiURI.APP_PV + "/entity/info";
	public static final String	LOAN_DETAIL				= ApiURI.APP_PV + "/loan/detail";
	public static final String	ENTITY_STAKEHOLDER		= ApiURI.APP_PV + "/entity/stakeholder";
	public static final String	STAKEHOLDER_NEXT		= ApiURI.APP_PV + "/stakeholder/next";
	public static final String	PG_VERIFY				= ApiURI.APP_PV + "/pg/verify";
	public static final String	PG_ISVERIFIEDPG			= ApiURI.APP_PV + "/pg/upadteStatus";
	public static final String	LOAN_DOCUMENT			= ApiURI.APP_PV + "/loan/document";
	public static final String	LOAN_SUBMIT				= ApiURI.APP_PV + "/loan/submit";
	public static final String	UPDATE_UPLOAD			= ApiURI.APP_PV + "/loan/update/documentBatch";

	// dip controller
	public static final String	DIP_CHECK				= ApiURI.APP_PV + "/dip/progress";

	// company controller
	public static final String	COMPANY_PV				= ApiURI.PRIVATE_PREFIX + "/applications/entity";
	public static final String	INDUSTRY				= ApiURI.COMPANY_PV + "/industry/mapping";

	public static final String	BUSINESS				= ApiURI.COMPANY_PV + "/business";
	public static final String	CONNECTED				= ApiURI.COMPANY_PV + "/connected";
	public static final String	VAT						= ApiURI.COMPANY_PV + "/vat";

	// sms controller
	public static final String	REQUEST					= ApiURI.PUBLIC_PREFIX + "/sms/otp/request";
	public static final String	VERIFICATION			= ApiURI.PUBLIC_PREFIX + "/sms/otp/verification";

	// health check controller
	public static final String	HEALTH_CHECK_INTERNAL	= ApiURI.INTERNAL_PREFIX + "/healthcheck";
	public static final String	HEALTH_CHECK_PUBLIC		= ApiURI.PUBLIC_PREFIX + "/healthcheck";

}
