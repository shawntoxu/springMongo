package com.test.app.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.test.app.model.UserClientInfo;

import eu.bitwalker.useragentutils.Browser;
import eu.bitwalker.useragentutils.UserAgent;

/**
 * 系统工具类
 *
 * @author TANGYINGQUAN360
 *
 */
public class CommonUtil {
	private static final String DATA_MATCHER = "^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))(\\s(((0?[0-9])|(1[0-9])|(2[0-3]))\\:([0-5]?[0-9])((\\s)|(\\:([0-5]?[0-9])))))?$";

	public static boolean isRunLocal(final String[] envs) {
		List<String> list = Arrays.asList(envs);
		if (list.contains("local") || list.contains("Local") || list.contains("LOCAL")) {
			return true;
		} else {
			return false;
		}
	}

	public static String describe(final Object obj) throws Exception {
		Map<String, String> objMap = BeanUtils.describe(obj);
		return objMap.toString();
	}

	public static <T> T parseJSON2Bean(final String jsonStr, final Class<T> clazz) {
		JSONObject json = JSON.parseObject(jsonStr);
		return JSON.toJavaObject(json, clazz);
	}

	public static boolean checkIP(final String s) {
		Pattern pattern = Pattern.compile("^((\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5]"
				+ "|[*])\\.){3}(\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5]|[*])$");
		return pattern.matcher(s).matches();
	}

	public static String bytes2Hex(final byte[] inbuf) {
		int i;
		String byteStr;
		StringBuffer strBuf = new StringBuffer();
		for (i = 0; i < inbuf.length; i++) {
			byteStr = Integer.toHexString(inbuf[i] & 0x00ff);
			if (byteStr.length() != 2) {
				strBuf.append('0').append(byteStr);
			} else {
				strBuf.append(byteStr);
			}
		}
		return new String(strBuf);
	}

	public static byte[] hexToBytes(final String inbuf) {
		int i;
		int len = inbuf.length() / 2;
		byte outbuf[] = new byte[len];
		for (i = 0; i < len; i++) {
			String tmpbuf = inbuf.substring(i * 2, i * 2 + 2);

			outbuf[i] = (byte) Integer.parseInt(tmpbuf, 16);
		}
		return outbuf;
	}

	public static boolean anyBlank(final String... values) {
		for (int i = 0; i < values.length; i++) {
			if (StringUtils.isBlank(values[i])) {
				return true;
			}
		}
		return false;
	}

	// length of d: [low, high]
	public static boolean pureDigit(String d, final int low, final int high) {
		if (low > high) {
			return false;
		}
		String regex = "\\d{" + low + "," + high + "}";
		d = d.replaceAll("\\s+", "");
		if (d.matches(regex)) {
			return true;
		}
		return false;
	}

	public static boolean isDate(final String strDate) {
		Pattern pattern = Pattern.compile(CommonUtil.DATA_MATCHER);
		Matcher m = pattern.matcher(strDate);
		return m.matches();
	}

	public static String getRandomString(final int length) {
		String base = "abcdefghijklmnopqrstuvwxyzQWERTYUIOPLKJHGFDSAZXCVBNM0123456789!@#$%-=+[]{}()*&^?><,.:;";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(base.length());
			sb.append(base.charAt(number));
		}
		return sb.toString();
	}

	public static String getBatchNumber() {
		String uuid = UUID.randomUUID().toString();

		return uuid.replaceAll("-", "").substring(0, 15);
	}

	public static String getCurrentDate(final String format) {
		return new SimpleDateFormat(format).format(new Date()).toString();
	}

	public static boolean containSpecialChar(final String str) {
		String regEx = "[ _`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]|\n|\r|\t";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(str);
		return m.find();
	}

	public static String formatDate(final Date date, final String pattern) {
		return DateFormatUtils.format(date, pattern);
	}

	// "20180506111222" -> 06/05/2018
	public static Date strToDate(final String date, String... format) {
		// format e.g : "yyyy.MM.dd"
		try {
			if (format.length > 1) {
				DateFormat srcFmt = new SimpleDateFormat(format[0]);
				Date dt = srcFmt.parse(StringUtils.trim(date));
				String strDate = formatDate(dt, format[1]);
				DateFormat targetFmt = new SimpleDateFormat(format[1]);
				return targetFmt.parse(strDate);
			} else {
				DateFormat srcFmt = new SimpleDateFormat(format[0]);
				return srcFmt.parse(StringUtils.trim(date));
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean checkObjFieldIsNull(final Object obj, final String... ignoreProperty)
			throws IllegalAccessException {
		boolean flag = false;
		for (Field f : obj.getClass().getDeclaredFields()) {
			f.setAccessible(true);
			if (StringUtils.indexOfAny(f.getName(), ignoreProperty) != -1) {
				continue;
			}
			if (f.get(obj) == null) {
				flag = true;
				return flag;
			}
		}
		return flag;
	}

	public static String getDisplayPhoneNumber(final String phoneNumber) {
		if (phoneNumber.length() < 11) {
			return null;
		}
		String displayPhoneNumber = "";
		if (phoneNumber.startsWith("86")) {
			displayPhoneNumber = phoneNumber.substring(0, 5);
		} else if (phoneNumber.startsWith("+86")) {
			displayPhoneNumber = phoneNumber.substring(0, 6);
		}
		return displayPhoneNumber + "****" + phoneNumber.substring(phoneNumber.length() - 4, phoneNumber.length());
	}

	public static UserClientInfo getClientInfo(HttpServletRequest request) {
		com.test.app.model.UserClientInfo userClientInfo = new UserClientInfo();
		String remoteAddr = null;
		String ip = request.getHeader("X-Real-IP");
		if (StringUtils.isNotEmpty(ip) && !"unknown".equalsIgnoreCase(ip)) {
			int index = ip.indexOf(',');
			if (index != -1) {
				remoteAddr = ip.substring(0, index);
			} else {
				remoteAddr = ip;
			}
		}
		if (StringUtils.isBlank(remoteAddr)) {
			remoteAddr = request.getHeader("X-FORWARDED-FOR");
		}
		if (StringUtils.isBlank(remoteAddr)) {
			remoteAddr = request.getRemoteAddr();
		}
		userClientInfo.setIpAddr(remoteAddr);

		Cookie[] cookies = request.getCookies();
		StringBuffer cookieStr = new StringBuffer();
		// get all cookies ??
		if (null != cookies) {
			for (Cookie cookie : cookies) {
				if (!"JSESSIONID".equalsIgnoreCase(cookie.getName()))
					cookieStr.append(cookie.getName()).append(":").append(cookie.getValue());
			}
		}
		if (cookieStr.toString().length() > 50) {
			userClientInfo.setCookieId(cookieStr.toString().substring(0, 50));
		} else {
			userClientInfo.setCookieId(cookieStr.toString());
		}
		String userAgent = request.getHeader("User-Agent");
		UserAgent ug = UserAgent.parseUserAgentString(userAgent);
		Browser browser = ug.getBrowser();
		if (null != browser) {
			userClientInfo.setBrowser(browser.getName());
		}
		if (null != browser.getVersion(userAgent) && null != browser.getVersion(userAgent).getVersion()) {
			userClientInfo.setBrowserVersion(browser.getVersion(userAgent).getVersion());
		}
		if (null != ug.getOperatingSystem() && null != ug.getOperatingSystem().getName()) {
			userClientInfo.setOperationSystem(ug.getOperatingSystem().getName());
		}

		return userClientInfo;
	}

	public static Object initDefaultValue(Object obj) {
		String textValue = "";
		int numberValue = 0;
		Field[] fields = obj.getClass().getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
			try {
				if (field.getType().getName().equalsIgnoreCase("java.lang.String")) {
					field.set(obj, textValue);
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Integer")
						|| field.getType().getName().equalsIgnoreCase("long")
						|| field.getType().getName().equalsIgnoreCase("int")) {
					field.set(obj, numberValue);
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Long")) {
					field.set(obj, new Long(numberValue));
				}
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return obj;
	}

	public static String formatNumber(String num) {
		String tarNum = "0";
		long base = 10000;
		if (null == num)
			return tarNum;
		try {
			BigDecimal srcNum = new BigDecimal(StringUtils.trim(num));
			tarNum = srcNum.multiply(new BigDecimal(String.valueOf(base))).toString();
			if (StringUtils.indexOf(tarNum, ".") != -1) {
				return StringUtils.split(tarNum, ".")[0];
			}
			return tarNum;
		} catch (Exception e) {
			return tarNum;
		}
	}

}
