package com.test.app.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

/**
 * @author Shawn.wang
 * @version May 2, 2018 10:59:11 AM
 */
/**
 * <p>
 * <b> BaseDao ,Bussiness Dao Impl the getEntityClass() </b>
 * </p>
 */
public abstract class BaseDao<T> {
	private Logger			LOGGER	= LoggerFactory.getLogger(BaseDao.class);

	@Autowired
	private MongoTemplate	template;

	public MongoTemplate getTemplate() {
		return this.template;
	}

	public void setTemplate(final MongoTemplate template) {
		this.template = template;
	}

	protected abstract Class<T> getEntityClass();

	public boolean saveApplicationInfo(final T info) {
		try {
			this.getTemplate().save(info);
			return true;
		} catch (Exception e) {
			this.LOGGER.error("save data [" + info + "] db exception :" + e.toString());
		}
		return false;
	}

	// save java Object and give collectionName
	public boolean save(final T info, final String collectionName) {
		try {
			this.getTemplate().save(info, collectionName);
			return true;
		} catch (Exception e) {
			this.LOGGER.error("save collection name:{}", collectionName);
			this.LOGGER.error("save data [" + info + "] db exception :" + e.toString());
		}
		return false;
	}

	public void removeObject(final Map<String, Object> map) {
		Query query = new Query();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
			query.addCriteria(criteria);
		}
		findAndRemove(query);
	}

	public T queryApplicationByKey(final Map<String, Object> map) {
		Query query = new Query();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
			query.addCriteria(criteria);
		}
		return queryOneApplication(query);
	}

	// asc or desc
	public T queryApplicationByKeyWithOrder(final Map<String, Object> map, final Map<String, String> orderKey) {
		// query.sort().on("age", Order.DESCENDING);
		Query query = new Query();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
			query.addCriteria(criteria);
		}
		List<Order> orders = new ArrayList<Order>();
		Direction order = null;
		for (Map.Entry<String, String> entry : orderKey.entrySet()) {
			if (null == entry.getValue()) {
				order = Direction.DESC;
			} else {
				order = entry.getValue().equalsIgnoreCase("asc") ? Direction.ASC : Direction.DESC;
			}
			orders.add(new Order(order, entry.getKey()));
		}
		query.with(new Sort(orders));
		return queryOneApplication(query);
	}

	public T queryApplicationByMutiValue(final Map<String, Object> equalsMap, final Map<String, List<Object>> ormap) {
		Query query = new Query();
		Criteria criteriaAll = new Criteria();
		List<Criteria> criteriaList = new ArrayList<Criteria>();

		// create and xxx1=b1 and xxx2=d2 .......
		for (Map.Entry<String, Object> entry : equalsMap.entrySet()) {
			Criteria tempCriteria = Criteria.where(entry.getKey()).is(entry.getValue());
			criteriaList.add(tempCriteria);
		}

		// create xxx in('a','b',.....)
		Criteria orCriteria = new Criteria();
		for (Map.Entry<String, List<Object>> entry : ormap.entrySet()) {
			List<Object> values = (List<Object>) entry.getValue();
			orCriteria = Criteria.where(entry.getKey()).in(values);
			criteriaList.add(orCriteria);
		}

		// create and xxx1=b1 and xxx2=d2 ....... and xxx3 in('a','b',.....)
		Criteria[] equalCriteriaArr = (Criteria[]) criteriaList.toArray(new Criteria[0]);
		criteriaAll.andOperator(equalCriteriaArr);
		query.addCriteria(criteriaAll);

		return queryOneApplication(query);
	}

	public void findAndRemove(final Query query) {
		this.getTemplate().remove(query, this.getEntityClass());
	}

	public T queryOneApplication(final Query query) {
		return this.getTemplate().findOne(query, this.getEntityClass());
	}

}
