package com.test.app.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

@SuppressWarnings("restriction")
public class DataSecurityUtil {
    private static final String KEY_ALGORITHM = "AES";
    private static final String CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    private static final String KEY_SEED = "IAMIS1236545789@q9879083(&&*%^&4q2-3472849231!#$HAHA";

    public static String digest(final byte[] oriByte) throws Exception {
        MessageDigest md = null;
        String strDes = null;
        try {
            md = MessageDigest.getInstance("SHA1");
            md.update(oriByte);
            strDes = CommonUtil.bytes2Hex(md.digest());
        } catch (Exception e) {
            throw new Exception("E000016", e);
        }
        return strDes;
    }

    public static String signData(final String data, final String storePassword, final String storeAlias) throws Exception {
        try {
            PrivateKey key = getPrivateKey(storePassword, storeAlias);
            Signature sig = Signature.getInstance("SHA1WithRSA");
            sig.initSign(key);
            sig.update(data.getBytes(StandardCharsets.UTF_8));
            byte[] sigBytes = sig.sign();
            BASE64Encoder encoder = new BASE64Encoder();
            return encoder.encodeBuffer(sigBytes);
        } catch (Exception e) {
            throw new Exception("E000012", e);
        }
    }

    public static boolean verifyData(final String data, final String signValue) {
        boolean flag = false;
        try {
            PublicKey key = getPublicKey();
            Signature sig = Signature.getInstance("SHA1WithRSA");
            sig.initVerify(key);
            sig.update(data.getBytes(StandardCharsets.UTF_8));
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] signValueByte = decoder.decodeBuffer(signValue);
            if (!sig.verify(signValueByte)) {
                flag = false;
            }
            flag = true;
        } catch (Exception e) {
            flag = false;
        }

        return flag;
    }

    public static PublicKey getPublicKey() throws Exception {
        InputStream is = null;
        try {
            is = DataSecurityUtil.class.getClassLoader().getResourceAsStream("certs/credoo_prod.cer");
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) cf.generateCertificate(is);
            return cert.getPublicKey();
        } catch (CertificateException e) {
            throw new Exception("E000030");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static PrivateKey getPrivateKey(final String storePassword, final String storeAlias) throws Exception {
        char[] storePwdArr;
        int i;
        BufferedInputStream bis = null;
        try {
            KeyStore ks = KeyStore.getInstance("JKS");
            InputStream fis = DataSecurityUtil.class.getClassLoader().getResourceAsStream("certs/credoo_prod.jks");
            bis = new BufferedInputStream(fis);
            storePwdArr = new char[storePassword.length()];// store password
            for (i = 0; i < storePassword.length(); i++) {
                storePwdArr[i] = storePassword.charAt(i);
            }
            ks.load(bis, storePwdArr);
            PrivateKey priv = (PrivateKey) ks.getKey(storeAlias, storePwdArr);
            return priv;
        } catch (KeyStoreException e) {
            e.printStackTrace();
            throw new Exception("E000033");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new Exception("E000031", e);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            throw new Exception("E000032", e);
        } catch (CertificateException e) {
            e.printStackTrace();
            throw new Exception("E000030", e);
        } catch (IOException e) {
            e.printStackTrace();
            throw new Exception("E000033", e);
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
            throw new Exception("E000033", e);
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String decrypt(final String sealTxt, final String keyStr) throws Exception {
        try {
            Cipher cipher = null;
            byte[] byteFina = null;
            SecretKey key = getKey(keyStr);
            try {
                cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
                cipher.init(Cipher.DECRYPT_MODE, key);
                BASE64Decoder decoder = new BASE64Decoder();
                byte[] sealByte = decoder.decodeBuffer(sealTxt);
                byteFina = cipher.doFinal(sealByte);
                return new String(byteFina, StandardCharsets.UTF_8);
            } catch (Exception e) {
                throw new Exception("E000034", e);
            } finally {
                cipher = null;
            }
        } catch (Exception ee) {
            throw new Exception(ee);
        }
    }

    public static String encrypt(final byte[] oriByte, final String keyStr) throws Exception {
        try {
            byte[] sealTxt = null;
            SecretKey key = getKey(keyStr);
            Cipher cipher = null;
            try {
                cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
                cipher.init(Cipher.ENCRYPT_MODE, key);
                sealTxt = cipher.doFinal(oriByte);
                BASE64Encoder encoder = new BASE64Encoder();
                String ret = encoder.encode(sealTxt);
                return ret;
            } catch (Exception e) {
                throw new Exception("E000035", e);
            } finally {
                cipher = null;
            }
        } catch (Exception ee) {
            throw new Exception(ee);
        }
    }

    public static SecretKey getKey(final String key) throws Exception {
        try {
            // 实例化DESede密钥
            DESedeKeySpec dks = new DESedeKeySpec(key.getBytes(StandardCharsets.UTF_8));
            // 实例化密钥工厂
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            // 生成密钥
            SecretKey secretKey = keyFactory.generateSecret(dks);
            return secretKey;
        } catch (Exception e) {
            throw new Exception("E000036", e);
        }
    }


    // toByteArray and toObject are taken from: http://tinyurl.com/69h8l7x
    public static byte[] toByteArray(final Object obj) throws IOException {
        byte[] bytes = null;
        ByteArrayOutputStream bos = null;
        ObjectOutputStream oos = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            bytes = bos.toByteArray();
        } finally {
            if (oos != null) {
                oos.close();
            }
            if (bos != null) {
                bos.close();
            }
        }
        return bytes;
    }

    public static Object toObject(final byte[] bytes) throws IOException, ClassNotFoundException {
        Object obj = null;
        ByteArrayInputStream bis = null;
        ObjectInputStream ois = null;
        try {
            bis = new ByteArrayInputStream(bytes);
            ois = new ObjectInputStream(bis);
            obj = ois.readObject();
        } finally {
            if (bis != null) {
                bis.close();
            }
            if (ois != null) {
                ois.close();
            }
        }
        return obj;
    }

    public static Key getKey() {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(DataSecurityUtil.KEY_SEED.getBytes(StandardCharsets.UTF_8));
            KeyGenerator generator = KeyGenerator.getInstance(DataSecurityUtil.KEY_ALGORITHM);
            generator.init(secureRandom);
            return generator.generateKey();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public static String encrypt(final String msg) {

        try {
            Key key = getKey();
            Cipher cipher = Cipher.getInstance(DataSecurityUtil.CIPHER_ALGORITHM);

            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptmsg = cipher.doFinal(msg.getBytes(StandardCharsets.UTF_8));
            BASE64Encoder encoder = new BASE64Encoder();
            String encoded = encoder.encode(encryptmsg);
            return encoded;
        } catch (Exception e) {
        }
        return null;
    }

    public static String encrypt(final Object obj) {

        try {
            Key key = getKey();
            Cipher cipher = Cipher.getInstance(DataSecurityUtil.CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptmsg = cipher.doFinal(toByteArray(obj));
            BASE64Encoder encoder = new BASE64Encoder();
            String encoded = encoder.encode(encryptmsg);
            return encoded;
        } catch (Exception e) {
        }
        return null;
    }

    public static byte[] decryptByte(final String encryptmsg) {
        try {
            Key key = getKey();
            Cipher cipher = Cipher.getInstance(DataSecurityUtil.CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] c = decoder.decodeBuffer(encryptmsg);
            byte[] result = cipher.doFinal(c);
            return result;
        } catch (Exception e) {
        }
        return null;
    }

    public static Object decryptObject(final String encryptmsg) {
        byte[] by = decryptByte(encryptmsg);
        try {
            return toObject(by);
        } catch (ClassNotFoundException e) {
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(final String encryptmsg) {
        byte[] by = decryptByte(encryptmsg);
        String plainText = new String(by, StandardCharsets.UTF_8);

        return plainText;
    }
}
