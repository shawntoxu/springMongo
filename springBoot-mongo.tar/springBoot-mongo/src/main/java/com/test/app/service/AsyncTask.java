package com.test.app.service;

import org.springframework.stereotype.Service;

/**
 * @author Shawn.wang
 * @version Jul 19, 2018 3:55:26 PM
 */
@Service
public interface AsyncTask<T> {
	public void startAsyncTask(String appId, T t);
}
