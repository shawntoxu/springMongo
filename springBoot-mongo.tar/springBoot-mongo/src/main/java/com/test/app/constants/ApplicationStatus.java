package com.test.app.constants;

/**
 * @author Shawn.wang
 * @version Apr 24, 2018 11:17:44 AM
 */
/**
 * <p>
 * <b> LoanApplication table status Filed </b>
 * </p>
 */
public class ApplicationStatus {
	public static final int	STARTEDNOTUPLOAD	= 1;
	public static final int	RECEIVED			= 2;
	public static final int	REJECTED			= 3;
	public static final int	PROCESSING			= 4;
	public static final int	APPROVED			= 5;
	public static final int	DISBURSEMENT		= 6;

}
