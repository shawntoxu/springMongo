package com.test.app.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.test.app.service.AsyncTask;

/**
 * @author Shawn.wang
 * @version Jul 19, 2018 3:16:55 PM
 */

@Service
public abstract class AsyncTaskImpl<T> implements AsyncTask<T> {
	private Logger LOGGER = LoggerFactory.getLogger(AsyncTaskImpl.class);

	public void startAsyncTask(String appId, T t) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				LOGGER.debug("run async task {}-thread  begin", appId);
				try {
					doBussiness(appId, t);
				} catch (Exception e) {
					LOGGER.error("run async task {}-thread failed ", appId);
					e.printStackTrace();
				}
				LOGGER.debug("run async task {}-thread  end", appId);
			}
		}, appId + "-thread").start();
	}

	protected abstract void doBussiness(String appId, T t) throws Exception;
}
