package com.test.app.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author Shawn.wang
 * @version May 23, 2018 6:43:27 PM
 */
@Configuration
@ConfigurationProperties(prefix = "JWTtoken")
public class JWTtokenConfig {
	private String	headKey;
	private String	headValue;
	private String	typeKey;
	private String	typeValue;
	private String	expirationKey;
	private String	expirationValue;
	private String	url;

	public String getHeadKey() {
		return this.headKey;
	}

	public void setHeadKey(final String headKey) {
		this.headKey = headKey;
	}

	public String getHeadValue() {
		return this.headValue;
	}

	public void setHeadValue(final String headValue) {
		this.headValue = headValue;
	}

	public String getTypeKey() {
		return this.typeKey;
	}

	public void setTypeKey(final String typeKey) {
		this.typeKey = typeKey;
	}

	public String getTypeValue() {
		return this.typeValue;
	}

	public void setTypeValue(final String typeValue) {
		this.typeValue = typeValue;
	}

	public String getExpirationKey() {
		return this.expirationKey;
	}

	public void setExpirationKey(final String expirationKey) {
		this.expirationKey = expirationKey;
	}

	public String getExpirationValue() {
		return this.expirationValue;
	}

	public void setExpirationValue(final String expirationValue) {
		this.expirationValue = expirationValue;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(final String url) {
		this.url = url;
	}

}
