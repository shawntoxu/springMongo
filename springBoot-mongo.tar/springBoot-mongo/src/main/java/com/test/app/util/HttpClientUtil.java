package com.test.app.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.util.PublicSuffixMatcher;
import org.apache.http.conn.util.PublicSuffixMatcherLoader;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import net.sf.json.JSONException;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertySetStrategy;

public class HttpClientUtil {
	private RequestConfig			requestConfig	= RequestConfig.custom().setSocketTimeout(30000)
			.setConnectTimeout(30000).setConnectionRequestTimeout(30000).build();

	private static HttpClientUtil	instance		= null;

	private HttpClientUtil() {
	}

	public static HttpClientUtil getInstance() {
		if (HttpClientUtil.instance == null) {
			HttpClientUtil.instance = new HttpClientUtil();
		}
		return HttpClientUtil.instance;
	}

	public String sendHttpPost(final String httpUrl) {
		HttpPost httpPost = new HttpPost(httpUrl);
		return sendHttpPost(httpPost);
	}

	public String sendHttpPost(final String httpUrl, final String params) {
		HttpPost httpPost = new HttpPost(httpUrl);
		try {
			StringEntity stringEntity = new StringEntity(params, "UTF-8");
			stringEntity.setContentType("application/json;charset=UTF-8");
			httpPost.setEntity(stringEntity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sendHttpPost(httpPost);
	}

	// public String sendHttpPost(final String httpUrl, final Map<String,
	// String> maps) {
	// HttpPost httpPost = new HttpPost(httpUrl);
	// List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	// for (String key : maps.keySet()) {
	// nameValuePairs.add(new BasicNameValuePair(key, maps.get(key)));
	// }
	// try {
	// httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// return sendHttpPost(httpPost);
	// }

	public String sendHttpPost(final String httpUrl, final Map<Object, Object> maps) {
		HttpPost httpPost = new HttpPost(httpUrl);
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		for (Object key : maps.keySet()) {
			nameValuePairs.add(new BasicNameValuePair((String) key, (String) maps.get(key)));
		}
		try {
			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sendHttpPost(httpPost);
	}

	public String sendHttpPost(final String httpUrl, final Map<String, String> maps, final List<File> fileLists) {
		HttpPost httpPost = new HttpPost(httpUrl);
		MultipartEntityBuilder meBuilder = MultipartEntityBuilder.create();
		for (String key : maps.keySet()) {
			meBuilder.addPart(key, new StringBody(maps.get(key), ContentType.TEXT_PLAIN));
		}
		for (File file : fileLists) {
			FileBody fileBody = new FileBody(file);
			meBuilder.addPart("files", fileBody);
		}
		HttpEntity reqEntity = meBuilder.build();
		httpPost.setEntity(reqEntity);
		return sendHttpPost(httpPost);
	}

	private String sendHttpPost(final HttpPost httpPost) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			httpClient = HttpClients.createDefault();
			httpPost.setConfig(this.requestConfig);
			response = httpClient.execute(httpPost);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	public String sendHttpGet(final String httpUrl) {
		HttpGet httpGet = new HttpGet(httpUrl);
		return sendHttpGet(httpGet);
	}

	public String sendHttpsGet(final String httpUrl) {
		HttpGet httpGet = new HttpGet(httpUrl);
		return sendHttpsGet(httpGet);
	}

	private String sendHttpGet(final HttpGet httpGet) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			httpClient = HttpClients.createDefault();
			httpGet.setConfig(this.requestConfig);
			response = httpClient.execute(httpGet);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	/**
	 * 
	 * @param httpPost
	 * @return
	 */
	private String sendHttpsGet(final HttpGet httpGet) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			PublicSuffixMatcher publicSuffixMatcher = PublicSuffixMatcherLoader
					.load(new URL(httpGet.getURI().toString()));
			DefaultHostnameVerifier hostnameVerifier = new DefaultHostnameVerifier(publicSuffixMatcher);
			httpClient = HttpClients.custom().setSSLHostnameVerifier(hostnameVerifier).build();
			httpGet.setConfig(this.requestConfig);
			response = httpClient.execute(httpGet);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	public JsonConfig setJsonConfig(final Class cls) {
		JsonConfig cfg = new JsonConfig();
		cfg.setPropertySetStrategy(new PropertyStrategyWrapper(PropertySetStrategy.DEFAULT));
		cfg.setRootClass(cls);
		return cfg;
	}

	private class PropertyStrategyWrapper extends PropertySetStrategy {
		private PropertySetStrategy original;

		public PropertyStrategyWrapper(final PropertySetStrategy original) {
			this.original = original;
		}

		@Override
		public void setProperty(final Object o, final String string, final Object o1) throws JSONException {
			try {
				this.original.setProperty(o, string, o1);

			} catch (Exception ex) {
			}

		}
	}
}
