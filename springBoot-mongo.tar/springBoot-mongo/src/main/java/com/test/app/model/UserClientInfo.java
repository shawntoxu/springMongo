package com.test.app.model;

import com.test.app.util.CommonUtil;

/**
 * @author Shawn.wang
 * @version Jun 14, 2018 3:58:45 PM
 */
public class UserClientInfo {

	private String	browser;
	private String	browserVersion;
	private String	operationSystem;
	private String	ipAddr;
	private String	cookieId;

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

	public String getOperationSystem() {
		return operationSystem;
	}

	public void setOperationSystem(String operationSystem) {
		this.operationSystem = operationSystem;
	}

	public String getIpAddr() {
		return ipAddr;
	}

	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	public String getCookieId() {
		return cookieId;
	}

	public void setCookieId(String cookieId) {
		this.cookieId = cookieId;
	}

	public UserClientInfo() {
		CommonUtil.initDefaultValue(this);
	}
}
