/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2018. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.test.app.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

/**
 * <p>
 * <b> service to load file </b>
 * </p>
 */
@Component
public class FileUtil {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ResourceLoader resourceLoader;

    private final String classpathPrefix = "classpath";


    /**
     * <p>
     * <b> get file content. </b>
     * </p>
     *
     * @return file content as string
     * @throws IOException
     */
    public String getFileContent(final String path) {
        String content = null;
        if (path.startsWith(this.classpathPrefix)) {
            try {
                // read menu content from class path first
                Resource resource = this.resourceLoader.getResource(path);
                content = IOUtils.toString(resource.getInputStream(), "UTF-8");
            } catch (IOException e) {
                this.logger.error("read " + path + " file from class path exception.", e);
            }
        } else {
            try {
                // read menu content from file system
                content = FileUtils.readFileToString(new File(path), "UTF-8");
            } catch (IOException e) {
                this.logger.error("read " + path + " file from file system exception.", e);
            }
        }
        this.logger.debug("file content:" + content);

        return content;
    }

    public void writeFileContent(final String path, final String content) {
        try {
            // write content to file system
            FileUtils.writeStringToFile(new File(path), content, "UTF-8");
        } catch (IOException e) {
            this.logger.error("write file to:" + path + " exception.", e);
        }
    }

    public static String getFilenameThroughAbsPath(final String absPathName) {
        int i = absPathName.lastIndexOf("/");
        int j = absPathName.lastIndexOf("\\");
        if (i > j) {
            return absPathName.substring(i + 1);
        } else if (i < j) {
            return absPathName.substring(j + 1);
        } else {
            return absPathName;
        }
    }

}
