package com.test.app.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * <p>
 * <b> Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class TokenInterceptor extends HandlerInterceptorAdapter {
	private Logger	logger				= LoggerFactory.getLogger(this.getClass());
	// @Value("${cadabra.onboarding.e2eTrustTokenHeader}")
	private String	e2eTrustTokenHeader	= "assertion";

	@Value("${spring.profiles.active}")
	private String	envSurffix			= "dev";

	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
			throws Exception {
		// e2e trust token validation
		String e2eTrustToken = request.getHeader(this.e2eTrustTokenHeader);

		return false;
	}
}
