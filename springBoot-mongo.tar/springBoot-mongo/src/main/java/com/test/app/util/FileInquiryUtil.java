package com.test.app.util;

import java.text.SimpleDateFormat;

public class FileInquiryUtil {

	public final static String	FILENET_TIME_FORMAT			= "yyyyMMddHHmmssSSS";
	public final static String	FILENET_TITLE_TIME_FORMAT	= "yyyyMMdd_HHmmss_SSS";

	public static String formatFileNetDate() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(FileInquiryUtil.FILENET_TIME_FORMAT);
		// String timeStr = dateFormat.format(DateTimeUtils.getGMT8Time());
		// return timeStr;
		return null;
	}

	public static String formatFileNetTitleDate() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(FileInquiryUtil.FILENET_TITLE_TIME_FORMAT);
		return null;
	}

}
