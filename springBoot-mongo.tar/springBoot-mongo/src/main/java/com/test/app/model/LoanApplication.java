package com.test.app.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Shawn.wang
 * @create 2018-4-18 AM11:53:16
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoanApplication {

}
