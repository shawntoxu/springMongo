package com.shawn.local.test;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.RestTemplate;

public class HttpTestGet {

	public static void main(final String[] args) {
		// String geturl = "http://172.26.204.93:58084/UIBS/personal/credit";
		// String geturl2 =
		// "http://172.26.204.93:58084/UIBS/personal/jsonCredit";
		// String parm =
		// "?bankCode=0321&instCode=032104&name=张三&pbocUserName=010738&pbocUserPassword=12345678&certno=341200198812101450&certtype=0&queryReason=01&shenqingjianNo=987654321&system=CCAM";
		// String url = geturl2 + parm;
		// String responseContent =
		// HttpClientUtil.getInstance().sendHttpsGet(url);
		// System.out.println("reponse content:" + responseContent);
		RestTemplate restTemplate = new RestTemplate();
		String url = "getss";
		Map<String, String> body = new HashMap<String, String>();
		body.put("phoneNumber", "12345678911");
		String response = restTemplate.postForObject(url, body, String.class);

		System.out.println(response);
	}
}
