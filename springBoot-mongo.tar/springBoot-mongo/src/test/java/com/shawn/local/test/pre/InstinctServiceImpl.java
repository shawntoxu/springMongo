// package com.shawn.local.test.pre;
//
// import java.util.ArrayList;
// import java.util.Calendar;
// import java.util.Date;
// import java.util.List;
//
// import org.apache.commons.lang.StringUtils;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
//
// import com.alibaba.fastjson.JSON;
// import com.alibaba.fastjson.TypeReference;
//
// import net.sf.json.JSONObject;
//
/// **
// * @author Shawn.wang
// * @version Jun 6, 2018 5:00:50 PM
// */
// @Service
// public class InstinctServiceImpl extends AsyncTaskImpl<UserClientInfo>
// implements InstinctService<UserClientInfo> {
// private Logger LOGGER = LoggerFactory.getLogger(InstinctServiceImpl.class);
//
// @Autowired
// private ApplicationDao ApplicationDao;
// @Autowired
// private PreScreeningDao preScreeningDao;
// @Autowired
// private UnionPayService unionPayService;
// @Autowired
// private QianHaiService qianHaiService;
// @Autowired
// private RestTemplateUtil restTemplateUtil;
//
// @Autowired
// private RBBConfig rbbConfig;
//
// private Stakeholder queryLegalperson(LoanApplication loanApp) {
// if (null != loanApp.getStakeholder() && loanApp.getStakeholder().size() > 0)
// {
// for (Stakeholder sh : loanApp.getStakeholder()) {
// if (sh.isLegalRepresentative()) {
// return sh;
// }
// }
// }
// return null;
// }
//
// private List<GuarantorCategory> getAllGuarantor(LoanApplication loanApp) {
// List<GuarantorCategory> guarantorList = new ArrayList<GuarantorCategory>();
// if (null != loanApp.getStakeholder() && loanApp.getStakeholder().size() > 0)
// {
// for (Stakeholder sh : loanApp.getStakeholder()) {
// if (sh.isGuarantor()) {
// GuarantorCategory guarantor = new GuarantorCategory();
// // TODO set I + ID ???
// guarantor.setThirdPartyName(sh.getName());
// if (null != sh.getIdCardNumber()) {
// guarantor.setThirdPartyID(sh.getIdCardNumber());
// }
// if (null != sh.getCellphone()) {
// guarantor.setThirdPartyMobile(sh.getCellphone());
// }
// if (null != sh.getRegistAddress()) {
// guarantor.setThirdPartyHomeAddr1(sh.getRegistAddress());
// }
// // TODO set Legal person ??
// guarantor.setThirdPartyReleationship("Legal person");
// // TODO
// // guarantor.setThirdPartyHomeAddr2();
// // guarantor.setThirdPartyHomeAddr3();
// // guarantor.setThirdPartyHomeAddr4();
// // guarantor.setThirdPartyHomeAddr5();
// guarantorList.add(guarantor);
// }
//
// }
// }
// return guarantorList;
// }
//
// public void sendInstinctData(LoanApplication loanApp, UserClientInfo
// userClientinfo) {
// Stakeholder legalPerson = queryLegalperson(loanApp);
// List<U2ACategory> u2a =
// unionPayService.getInstinctData(legalPerson.getIdCardNumber());
// InstinctRequest request = new InstinctRequest();
// request.setU2a(u2a);
//
// // Application Category
// AppInfo hkb = new AppInfo();
// hkb.setAppNumber(loanApp.get_id());
// Date appDate = CommonUtil.strToDate(loanApp.getStartDate(), "yyyyMMddHHmmss",
// "dd/MM/yyyy");
// hkb.setAppDate(appDate);
// hkb.setCaputreDate(appDate);
//
// // Expiry Date (Application Date + 6 months) DD/MM/YYYY
// Calendar expiryDate = Calendar.getInstance();
// expiryDate.setTime(appDate);
// expiryDate.add(Calendar.MONTH, +6);
// hkb.setExpiryDate(expiryDate.getTime());
// hkb.setReqLimit(loanApp.getLoanDetails().getAmount());
//
// request.setHkb(hkb);
//
// // Applicant Category ,Guarantor Category ,
// // User Category(2nd Language)
// Applicat applicat = new Applicat();
// applicat.setId1("I" + legalPerson.getIdCardNumber());
// // email TODO ??
// applicat.setEmail("");
//
// User2ndCategory user = new User2ndCategory();
// user.setSecLanguageFirstname(legalPerson.getFirstNamePinyin());
// user.setSecLanguageFullname(legalPerson.getLastNamePinyin());
//
// request.setApplicat(applicat);
// request.setGuarantor(getAllGuarantor(loanApp));
// request.setUser(user);
//
// PreScreening preScreeing =
// preScreeningDao.getLatestRecords(loanApp.getTokenId());
// if (null != preScreeing) {
// // Security Category
// SecurityCategory security = new SecurityCategory();
// if (null != preScreeing.getPreScreenRecord().get("product_type")) {
// security.setProductType(preScreeing.getPreScreenRecord().get("product_type"));
// }
// // TODO status = processing ??
// security.setAppStatus("processing");
// // 还款方式 TODO??? // will delete the field
// security.setPaymentMethod("");
// // 产品名称
// if
// (preScreeing.getPreScreenRecord().get("product_type").equalsIgnoreCase("Merchant
// Advance")
// ||
// preScreeing.getPreScreenRecord().get("product_type").equalsIgnoreCase("Term
// Loan")) {
// security.setProductName("Term Loan");
// } else if
// (preScreeing.getPreScreenRecord().get("product_type").equalsIgnoreCase("Revolving
// Line")) {
// security.setProductName("Revolving Line");
// }
//
// security.setLoanPurpose(getStrPurposeOfLoan(loanApp.getLoanDetails().getPurposeOfLoan(),
// loanApp));
// if (null != loanApp.getLoanDetails().getTenor()) {
// security.setLoanTermPeriod(String.valueOf(loanApp.getLoanDetails().getTenor()));
// }
// request.setSecurity(security);
// }
//
// // Valuer Category
// ValuerCategory valuer = new ValuerCategory();
// // 借款转入银行
// valuer.setLoanPayInBank(loanApp.getLoanDetails().getBankName());
// // 借款转入账号
// valuer.setLoanPayInCardNumbr(loanApp.getLoanDetails().getCardNumber());
// request.setValuer(valuer);
//
// // User 2 Category
// User2Category user2 = new User2Category();
// user2.setFourElementsCheckResult("passed");
// user2.setIpAddr(userClientinfo.getIpAddr());
// user2.setCookieId(userClientinfo.getCookieId());
// user2.setBrowser(userClientinfo.getBrowser());
// user2.setBrowserVersion(userClientinfo.getBrowserVersion());
// user2.setOperationSystem(userClientinfo.getOperationSystem());
//
// // TODO
// // legalPerson.getIdCardBack();
// // legalPerson.getCellphone();
//
// // Amazon's SELLER_STATUS
// if (null != preScreeing.getPreScreenRecord().get("sellerstatus")) {
// user2.setSellerStatus(preScreeing.getPreScreenRecord().get("sellerstatus"));
// }
//
// // Amazon's TENURE
// if (null != preScreeing.getPreScreenRecord().get("amazontenure")) {
// user2.setTenure(preScreeing.getPreScreenRecord().get("amazontenure"));
// }
//
// user2.setTokenId(loanApp.getTokenId());
// if (null != preScreeing.getPreScreenRecord().get("blockscore")) {
// user2.setBlockScore(preScreeing.getPreScreenRecord().get("blockscore"));
// }
// // Amazon's TTM_NEG_FEEDBACK
// if (null != preScreeing.getPreScreenRecord().get("ttmfeedback")) {
// user2.setNegFeedbackTTM(preScreeing.getPreScreenRecord().get("ttmfeedback"));
// }
// if (null !=
// preScreeing.getPreScreenRecord().get("negativeorderfeedbackrate")) {
// user2.setNegFeedbackOrder(preScreeing.getPreScreenRecord().get("negativeorderfeedbackrate"));
// }
// if (null != preScreeing.getPreScreenRecord().get("negativefeedbackrate")) {
// user2.setNegFeedbackRate(preScreeing.getPreScreenRecord().get("negativefeedbackrate"));
// }
// request.setUser2(user2);
//
// List<CbaCategory> cbaList = qianHaiService.getCbaCategory(loanApp);
// request.setCba(cbaList);
//
// sendInstinct(request, loanApp);
//
// }
//
// // set this to config file
// private String getStrPurposeOfLoan(int type, LoanApplication loanApp) {
// String str = "";
// switch (type) {
// case 1:
// str = "购买原材料";
// break;
// case 2:
// str = "采购维持生产所需的其他物品(固定资产投资除外)";
// break;
// case 3:
// str = "支付经营场所租金";
// break;
// case 4:
// str = "支付公共事务费 (水、电、煤等)";
// break;
// case 5:
// str = "支付员工工资";
// break;
// case 6:
// if (null != loanApp.getLoanDetails().getOtherPurposeOfLoan()) {
// str = loanApp.getLoanDetails().getOtherPurposeOfLoan();
// }
// break;
// default:
// break;
// }
// return str;
// }
//
// /**
// * 1 Clean -> C 2 Suspicious -> S 3 High Suspicious -> H 6 Manual check
// * ->NULL or api error
// *
// * @param instinctRequest
// * @param loanApp
// */
// private void sendInstinct(InstinctRequest instinctRequest, LoanApplication
// loanApp) {
// String requestBody = JSONObject.fromObject(instinctRequest).toString();
// EntityCheck entityCheck = loanApp.getEntityCheck();
// if (null == entityCheck) {
// entityCheck = new EntityCheck();
// }
// try {
// String responseContent =
// this.restTemplateUtil.postJsonWithHttps(this.rbbConfig.getInstinctUrl(),
// requestBody, null, false);
// InstinctResponse instinctResponse = JSON.parseObject(responseContent,
// new TypeReference<InstinctResponse>() {
// });
// LOGGER.debug("check instinct result : {}", responseContent);
//
// if (null != instinctResponse.getPayload()
// && StringUtils.isNotBlank(instinctResponse.getPayload().getFraudAlert())) {
//
// String value = instinctResponse.getPayload().getFraudAlert();
// switch (value) {
// case FraudCheckStatus.C:
// entityCheck.setFraudCheck(FraudCheckStatus.CLEAN);
// break;
// case FraudCheckStatus.S:
// entityCheck.setFraudCheck(FraudCheckStatus.SUSPICIOUS);
// break;
// case FraudCheckStatus.H:
// entityCheck.setFraudCheck(FraudCheckStatus.HIGHSUSPICIOUS);
// break;
// default:
// break;
// }
//
// } else if (null != instinctResponse.getPayload()
// && StringUtils.isBlank(instinctResponse.getPayload().getFraudAlert())) {
// entityCheck.setFraudCheck(FraudCheckStatus.MANUALCHECK);
// }
// loanApp.setEntityCheck(entityCheck);
// ApplicationDao.saveApplicationInfo(loanApp);
// } catch (Exception e) {
// // if instinct api system error
// entityCheck.setFraudCheck(FraudCheckStatus.MANUALCHECK);
// loanApp.setEntityCheck(entityCheck);
// ApplicationDao.saveApplicationInfo(loanApp);
// LOGGER.debug("send instinct request error url:{},send data : {}",
// this.rbbConfig.getInstinctUrl(),
// instinctRequest.toString());
// e.printStackTrace();
// }
//
// }
//
// @Override
// protected void doBussiness(LoanApplication loanApp, UserClientInfo
// userClientinfo) {
// sendInstinctData(loanApp, userClientinfo);
// }
//
// }
