//
// import java.io.File;
// import java.io.IOException;
// import java.net.URL;
// import java.util.HashMap;
// import java.util.Map;
//
// import javax.annotation.PostConstruct;
//
// import org.apache.commons.io.FileUtils;
// import org.apache.commons.lang.StringUtils;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.context.annotation.Profile;
// import org.springframework.stereotype.Service;
//
// import com.fasterxml.jackson.databind.ObjectMapper;
//
// import net.sf.json.JSONObject;
//
// @Service
// @Profile({ "UAT", "LOCAL", "SIT" })
// public class CupFactorServiceStubImpl implements CupFactorService {
//
// private Logger logger = LoggerFactory.getLogger(this.getClass());
//
// private String stubResourcePath = "classpath:/stub/cup/4elements/";
//
// private static Map<String, String> commonData = new HashMap<String,
// String>();
//
// @Autowired
// private CUPConfig cupConfig;
//
// @Autowired
// private FileUtil fileUtil;
//
// @Value("${spring.profiles.active}")
// private String envSurffix = "UAT";
//
// @PostConstruct
// public void init() {
// String appId = this.cupConfig.getAppId();
// String appKey = this.cupConfig.getAppKey();
//
// String envCup4file = StringUtils.split(SDKConfig.FILE_NAME, ".")[0] + "-" +
// envSurffix + "."
// + StringUtils.split(SDKConfig.FILE_NAME, ".")[1];
// URL url = this.getClass().getClassLoader().getResource(envCup4file);
//
// File source = new File(url.getPath());
// File target = new File(url.getPath().replaceFirst(envCup4file,
// SDKConfig.FILE_NAME));
// try {
// FileUtils.copyFile(source, target);
// } catch (IOException e) {
// e.printStackTrace();
// }
//
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_encoding,
// SDKConstants.encoding_UTF_8);
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_certId,
// CertUtil.getSignCertId());
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_version,
// SDKConstants.version_1);
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_signMethod,
// SDKConstants.signMethod_RSA_SHA);
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_appId, appId);
// CupFactorServiceStubImpl.commonData.put(SDKConstants.key_appKey, appKey);
// }
//
// public CupFactorResponse validateCUPFactor(final CupFactorRequest
// customerInfo) {
// CupFactorResponse response = null;
// String mobile = customerInfo.getPhoneNo();
// if (mobile.length() > 4 && mobile.substring(mobile.length() -
// 4).equals("0000")) {
// response = new CupFactorResponse();
// response.setRespCode(ResponseCode.CUP4_CHECK_FAILED.getCode());
// return response;
// }
//
// ObjectMapper objectMapper = new ObjectMapper();
// String stubFileName = "response.json";
// String stubFilePathNameOfMobile = this.stubResourcePath + stubFileName;
//
// try {
// String stub = this.fileUtil.getFileContent(stubFilePathNameOfMobile);
// JSONObject resp = JSONObject.fromObject(stub);
// response = objectMapper.readValue(
// resp.getJSONObject("responseBody").getJSONObject("cupFactorResponse").toString(),
// CupFactorResponse.class);
// } catch (IOException e) {
// e.printStackTrace();
// }
//
// return response;
// }
//
// public boolean validateCUP4Factors(final CupFactorRequest customerInfo) {
//
// String mobile = customerInfo.getPhoneNo();
// if (mobile.length() > 4 && mobile.substring(mobile.length() -
// 4).equals("0000")) {
// return false;
// }
//
// ObjectMapper objectMapper = new ObjectMapper();
// String stubFileName = "response.json";
// String stubFilePathNameOfMobile = this.stubResourcePath + stubFileName;
//
// try {
// String stub = this.fileUtil.getFileContent(stubFilePathNameOfMobile);
// JSONObject resp = JSONObject.fromObject(stub);
// objectMapper.readValue(resp.getJSONObject("responseBody").getJSONObject("cupFactorResponse").toString(),
// CupFactorResponse.class);
// } catch (IOException e) {
// this.logger.error(e.getMessage());
// return false;
// }
//
// return true;
// }
//
// @Override
// public String sendCpu4DataByHttp(final CupFactorRequest customerInfo) throws
// Exception {
// return null;
// }
//
// }
