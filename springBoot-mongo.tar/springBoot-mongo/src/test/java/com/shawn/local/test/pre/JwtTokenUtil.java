// package com.shawn.local.test.pre;
//
// import java.io.InputStream;
// import java.security.PublicKey;
// import java.security.cert.Certificate;
// import java.security.cert.CertificateException;
// import java.security.cert.CertificateFactory;
// import java.util.concurrent.TimeoutException;
//
// import org.apache.commons.lang.StringUtils;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
//
//
// import io.jsonwebtoken.Claims;
// import io.jsonwebtoken.ExpiredJwtException;
// import io.jsonwebtoken.Jwts;
// import io.jsonwebtoken.SignatureException;
//
// public class JwtTokenUtil {
//
// private static final Logger logger =
// LoggerFactory.getLogger(JwtTokenUtil.class);
//
// public JwtTokenUtil() {
// }
//
// public static String getJwtFromSaml(final String samlStr) {
// if (StringUtils.isBlank(samlStr)) {
// return null;
// }
// int startIdx = samlStr.indexOf(JwtTokenConstants.SAML_SIGNATURE_START);
// int endIdx = samlStr.indexOf(JwtTokenConstants.SAML_SIGNATURE_END);
// if (startIdx == -1 || endIdx == -1) {
// return null;
// }
// return samlStr.substring(startIdx +
// JwtTokenConstants.SAML_SIGNATURE_START.length(), endIdx);
// }
//
// public static Claims validateToken(final String token, final String
// envSurffix) throws Exception {
// String[] files = getFileList(envSurffix);
// Claims claims = null;
// if (files != null) {
// for (String keyName : files) {
// try {
// PublicKey publicKey = getPublicKey(keyName);
// claims =
// Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token).getBody();
// JwtTokenUtil.logger.debug("Successfully validated JWT with cert: " +
// keyName);
// return claims;
// } catch (SignatureException e) {
// JwtTokenUtil.logger.error("Failed to validate JWT, signature not match with
// cert: " + keyName);
// } catch (ExpiredJwtException e) {
// JwtTokenUtil.logger.error("Failed to validate JWT, token expired.", e);
// throw new TimeoutException("token expired");
// } catch (CertificateException e) {
// JwtTokenUtil.logger.error("get public key failed.", e);
// }
// }
// }
// return null;
// }
//
// private static String[] getFileList(final String space) {
// switch (space.toLowerCase()) {
// case "local":
// case "dev":
// case "sit":
// case "sct":
// case "mct":
// case "test":
// return new String[] { "/certs/RBB_OB_e2eTrust_dev.cer" };
// case "uat":
// case "cert":
// return new String[] { "/certs/RBB_OB_e2eTrust_uat1.cer",
// "/certs/RBB_OB_e2eTrust_uat2.cer" };
// case "prod":
// return new String[] { "/certs/RBB_OB_e2eTrust_tko1.cer",
// "/certs/RBB_OB_e2eTrust_tko2.cer",
// "/certs/RBB_OB_e2eTrust_skm1.cer", "/certs/RBB_OB_e2eTrust_skm2.cer" };
// default:
// return null;
// }
// }
//
// private static PublicKey getPublicKey(final String keyName) throws
// CertificateException {
// CertificateFactory certFact = CertificateFactory.getInstance("X.509");
// InputStream is = JwtTokenUtil.class.getResourceAsStream(keyName);
// Certificate cert = certFact.generateCertificate(is);
// return cert.getPublicKey();
// }
//
// }
