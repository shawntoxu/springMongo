package com.shawn.local.test;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.util.PublicSuffixMatcher;
import org.apache.http.conn.util.PublicSuffixMatcherLoader;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import net.sf.json.JSONObject;

public class HttpClientUtil {
	private RequestConfig			requestConfig	= RequestConfig.custom().setSocketTimeout(15000)
			.setConnectTimeout(15000).setConnectionRequestTimeout(15000).build();

	private static HttpClientUtil	instance		= null;

	private HttpClientUtil() {
	}

	public static HttpClientUtil getInstance() {
		if (HttpClientUtil.instance == null) {
			HttpClientUtil.instance = new HttpClientUtil();
		}
		return HttpClientUtil.instance;
	}

	/**
	 * 发送 post请求
	 * 
	 * @param httpUrl
	 *            地址
	 */
	public String sendHttpPost(final String httpUrl) {
		HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost
		return sendHttpPost(httpPost);
	}

	/**
	 * 发送 post请求
	 * 
	 * @param httpUrl
	 *            地址
	 * @param params
	 *            参数(格式:key1=value1&key2=value2)
	 */
	public String sendHttpPost(final String httpUrl, final String params) {
		HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost
		try {
			// 设置参数
			StringEntity stringEntity = new StringEntity(params, "UTF-8");
			stringEntity.setContentType("application/x-www-form-urlencoded");
			httpPost.setEntity(stringEntity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sendHttpPost(httpPost);
	}

	/**
	 * 发送 post请求
	 * 
	 * @param httpUrl
	 *            地址
	 * @param maps
	 *            参数
	 */
	public String sendHttpPost(final String httpUrl, final Map<String, String> maps) {
		HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost
		// 创建参数队列
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		for (String key : maps.keySet()) {
			nameValuePairs.add(new BasicNameValuePair(key, maps.get(key)));
		}
		try {
			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, "UTF-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sendHttpPost(httpPost);
	}

	/**
	 * 发送 post请求（带文件）
	 * 
	 * @param httpUrl
	 *            地址
	 * @param maps
	 *            参数
	 * @param fileLists
	 *            附件
	 */
	public String sendHttpPost(final String httpUrl, final Map<String, String> maps, final List<File> fileLists) {
		HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost
		MultipartEntityBuilder meBuilder = MultipartEntityBuilder.create();
		for (String key : maps.keySet()) {
			meBuilder.addPart(key, new StringBody(maps.get(key), ContentType.TEXT_PLAIN));
		}
		for (File file : fileLists) {
			FileBody fileBody = new FileBody(file);
			meBuilder.addPart("files", fileBody);
		}
		HttpEntity reqEntity = meBuilder.build();
		httpPost.setEntity(reqEntity);
		return sendHttpPost(httpPost);
	}

	/**
	 * 发送Post请求
	 * 
	 * @param httpPost
	 * @return
	 */
	private String sendHttpPost(final HttpPost httpPost) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			// 创建默认的httpClient实例.
			httpClient = HttpClients.createDefault();
			httpPost.setConfig(this.requestConfig);
			// 执行请求
			response = httpClient.execute(httpPost);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭连接,释放资源
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	/**
	 * 发送 get请求
	 * 
	 * @param httpUrl
	 */
	public String sendHttpGet(final String httpUrl) {
		HttpGet httpGet = new HttpGet(httpUrl);// 创建get请求
		return sendHttpGet(httpGet);
	}

	/**
	 * 发送 get请求Https
	 * 
	 * @param httpUrl
	 */
	public String sendHttpsGet(final String httpUrl) {
		HttpGet httpGet = new HttpGet(httpUrl);// 创建get请求
		return sendHttpsGet(httpGet);
	}

	/**
	 * 发送Get请求
	 * 
	 * @param httpPost
	 * @return
	 */
	private String sendHttpGet(final HttpGet httpGet) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			// 创建默认的httpClient实例.
			httpClient = HttpClients.createDefault();
			httpGet.setConfig(this.requestConfig);
			// 执行请求
			response = httpClient.execute(httpGet);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭连接,释放资源
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	/**
	 * 发送Get请求Https
	 * 
	 * @param httpPost
	 * @return
	 */
	private String sendHttpsGet(final HttpGet httpGet) {
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		HttpEntity entity = null;
		String responseContent = null;
		try {
			// 创建默认的httpClient实例.
			PublicSuffixMatcher publicSuffixMatcher = PublicSuffixMatcherLoader
					.load(new URL(httpGet.getURI().toString()));
			DefaultHostnameVerifier hostnameVerifier = new DefaultHostnameVerifier(publicSuffixMatcher);
			httpClient = HttpClients.custom().setSSLHostnameVerifier(hostnameVerifier).build();
			httpGet.setConfig(this.requestConfig);
			// 执行请求
			response = httpClient.execute(httpGet);
			entity = response.getEntity();
			responseContent = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭连接,释放资源
				if (response != null) {
					response.close();
				}
				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseContent;
	}

	public static String getData() {
		String geturl = "http://172.26.204.93:58084/UIBS/personal/credit";
		String geturl2 = "http://172.26.204.93:58084/UIBS/personal/jsonCredit";
		String parm = "?" + "bankCode=0321" + "&instCode=032104" + "&name=张三" + "&pbocUserName=010738"
				+ "&pbocUserPassword=12345678" + "&certno=341200198812101450" + "&certtype=0" + "&queryReason=01"
				+ "&shenqingjianNo=987654321" + "&system=CCAM";
		String url = geturl2 + parm;
		String responseContent = HttpClientUtil.getInstance().sendHttpsGet(url);
		System.out.println("========================================== ");
		System.out.println("reponse content: " + responseContent);
		return responseContent;
	}

	public static String getDataPost() {
		String url2 = "http://172.26.204.93:58084/UIBS/personal/jsonCredit";
		Map<String, String> maps = new HashMap<String, String>();
		maps.put("bankCode", "0321");
		// maps.put("queryReason", "01");
		// maps.put("shenqingjianNo", "987654321");
		// maps.put("certtype", "0");

		maps.put("instCode", "032104");
		maps.put("queryReason", "02");
		maps.put("shenqingjianNo", "45b6a7c715df4c622");
		maps.put("certtype", "0");
		maps.put("pbocUserName", "010738");
		maps.put("pbocUserPassword", "12345678");
		maps.put("system", "CCAM");
		// maps.put("forceQuery", "Y");
		// 610526198402110028
		// maps.put("certno", "61042419930721356X");
		// maps.put("name", "胡志荣");

		// 44122319741216001X
		// maps.put("certno", "610123199710101234");
		// maps.put("name", "胡志荣");

		// maps.put("certno", "421003198912083616");
		// maps.put("name", "周强");

		maps.put("certno", "642102197712170026");
		maps.put("name", "刘诗伟");

		// maps.put("certno", "421003198912083616");
		// maps.put("name", "周强");

		// maps.put("name", "张三");
		// maps.put("certno", "341200198812101450");
		String responseContent = HttpClientUtil.getInstance().sendHttpPost(url2, maps);

		System.out.println(JSONObject.fromObject(maps).toString());
		System.out.println("-------------");

		System.out.println(responseContent);

		return "{request:" + JSONObject.fromObject(maps).toString() + ",response:" + responseContent + "}";
		// ArchiveIndividualBureau archiveIndividualBureau = new
		// ArchiveIndividualBureau();
		// archiveIndividualBureau.setQueryTime(System.currentTimeMillis());
		// archiveIndividualBureau.setBizId("113");
		// archiveIndividualBureau.setObj(responseContent);
		// ApplicationContext ctx = new
		// AnnotationConfigApplicationContext(SpringMongoConfig.class);
		// MongoTemplate mongoTemplate = (MongoTemplate)
		// ctx.getBean("mongoTemplate");
		// mongoTemplate.save(archiveIndividualBureau);
		//
		// JSONObject obj = JSONObject.fromObject(responseContent);

		// System.out.println("========get obj =============");
		// System.out.println(obj.toString());
		// Map<String, Class> map = new HashMap<String, Class>();
		// map.put("overdueSum", OverdueSum.class);
		// map.put("creditSummaryCue", CreditSummaryCue.class);
		// map.put("contratInfo", ContratInfo.class);
		// map.put("fellbackSum", FellbackSum.class);
		// map.put("shareAndDebtSum", ShareAndDebtSum.class);
		// map.put("awardCreditInfo", AwardCreditInfo.class);
		// map.put("adminPunishment", AdminPunishment.class);
		// map.put("assetDisposition", AssetDisposition.class);
		// map.put("assurerRepay", AssurerRepay.class);
		// map.put("civilJudgement", CivilJudgement.class);
		// map.put("forceExecution", ForceExecution.class);
		// map.put("taxArrear", TaxArrear.class);
		// map.put("accFund", AccFund.class);
		// map.put("identity", Identity.class);
		// map.put("spouse", Spouse.class);
		// map.put("residence", Residence.class);
		// map.put("professional", Professional.class);
		// map.put("messageHeader", MessageHeader.class);
		// map.put("endowmentInsuramceDeposit",
		// EndowmentInsuramceDeposit.class);
		// map.put("queryReq", QueryReq.class);
		// map.put("recordDetail", RecordDetail.class);
		// map.put("reportSource", ReportSource.class);
		// map.put("calculateSegment", CalculateSegment.class);
		// map.put("assureLoanInfo", AssureLoanInfo.class);
		// map.put("creditCardAssureInfo", CreditCardAssureInfo.class);
		// map.put("telPayment", TelPayment.class);
		// map.put("numAnalysis", NumAnalysis.class);

		// JsonConfig cfg = new JsonConfig();
		//
		// cfg.setPropertySetStrategy(new
		// PropertyStrategyWrapper(PropertySetStrategy.DEFAULT));
		//
		// cfg.setRootClass(CreditReortResponse.class);
		//
		// try {
		// // CreditReortResponse result = (CreditReortResponse)
		// // JSONObject.toBean(obj, CreditReortResponse.class, map);
		// CreditReortResponse result = (CreditReortResponse)
		// JSONObject.toBean(obj, cfg);
		// System.out.println("========get result =============");
		// System.out.println(result.toString());
		// System.out.println("==========get string
		// ==========================");
		// if (null != result.getCreditSummaryCue()) {
		//
		// System.out.println(result.getCreditSummaryCue().getHouseLoanCount());
		// }
		// } catch (Exception e) {
		// System.out.println(e.toString());
		// }
		// CreditReortResponse result = (CreditReortResponse)
		// JSONObject.toBean(obj);

	}

	public static void test2() {
		String url = "https://ssss";
		String rs = HttpClientUtil.getInstance().sendHttpPost(url, FileBase64.getBase64());
		System.out.println(rs);
	}

	public static void main(final String[] args) {
		// test2();
		getDataPost();

	}
}
