package com.shawn.local.test;

import net.sf.json.JSONException;
import net.sf.json.util.PropertySetStrategy;

public class PropertyStrategyWrapper extends PropertySetStrategy {
    private PropertySetStrategy original;

    public PropertyStrategyWrapper(final PropertySetStrategy original) {
        this.original = original;
    }

    @Override
    public void setProperty(final Object o, final String string, final Object o1) throws JSONException {
        try {
            this.original.setProperty(o, string, o1);

        } catch (Exception ex) {
        }

    }
}