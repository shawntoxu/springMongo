package com.shawn.local.test;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;

/**
 * @author Shawn.wang
 * @version Jul 12, 2018 11:42:46 AM
 */
public class TestEncryptor {
	public static void main(String[] args) {
		// 加密工具
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		// 加密配置
		EnvironmentStringPBEConfig config = new EnvironmentStringPBEConfig();
		config.setAlgorithm("PBEWithMD5AndDES");
		// 自己在用的时候更改此密码
		config.setPassword("apdplat");
		// 应用配置
		encryptor.setConfig(config);
		String plaintext = "root";
		// 加密
		String ciphertext = encryptor.encrypt(plaintext);
		System.out.println(plaintext + " : " + ciphertext);

		// 解密
		String plaintext2 = encryptor.decrypt(ciphertext);
		System.out.println(ciphertext + " : " + plaintext2);

	}
}
