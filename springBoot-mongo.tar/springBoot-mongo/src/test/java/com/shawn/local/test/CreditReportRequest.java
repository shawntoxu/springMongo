package com.shawn.local.test;

public class CreditReportRequest {

    private String   bizCode;
    private String   certno;
    private String   certtype;
    private String   name;
    private Integer  queryDateSpacing;
    private String   queryReason;
    private String   reserve;
    private String   system;
    private String   userId;
    private String   forceQuery;       // 强制查询标记
    private String   shenqingjianNo;
    private String   pbocUserName;
    private String   pbocUserPassword;
    private String   bankCode;
    private String   instCode;
    private String   enqueryLoc;
    private String   resultCode;
    protected String ylzd1;
    protected String ylzd2;
    protected String ylzd3;
    protected String ylzd4;
    protected String ylzd5;
    protected String syjg;
    protected String currentActor;

    public String getBizCode() {
        return this.bizCode;
    }

    public void setBizCode(final String bizCode) {
        this.bizCode = bizCode;
    }

    public String getCertno() {
        return this.certno;
    }

    public void setCertno(final String certno) {
        this.certno = certno;
    }

    public String getCerttype() {
        return this.certtype;
    }

    public void setCerttype(final String certtype) {
        this.certtype = certtype;
    }

    public String getName() {
        return this.name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public Integer getQueryDateSpacing() {
        return this.queryDateSpacing;
    }

    public void setQueryDateSpacing(final Integer queryDateSpacing) {
        this.queryDateSpacing = queryDateSpacing;
    }

    public String getQueryReason() {
        return this.queryReason;
    }

    public void setQueryReason(final String queryReason) {
        this.queryReason = queryReason;
    }

    public String getReserve() {
        return this.reserve;
    }

    public void setReserve(final String reserve) {
        this.reserve = reserve;
    }

    public String getSystem() {
        return this.system;
    }

    public void setSystem(final String system) {
        this.system = system;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getForceQuery() {
        return this.forceQuery;
    }

    public void setForceQuery(final String forceQuery) {
        this.forceQuery = forceQuery;
    }

    public String getShenqingjianNo() {
        return this.shenqingjianNo;
    }

    public void setShenqingjianNo(final String shenqingjianNo) {
        this.shenqingjianNo = shenqingjianNo;
    }

    public String getPbocUserName() {
        return this.pbocUserName;
    }

    public void setPbocUserName(final String pbocUserName) {
        this.pbocUserName = pbocUserName;
    }

    public String getPbocUserPassword() {
        return this.pbocUserPassword;
    }

    public void setPbocUserPassword(final String pbocUserPassword) {
        this.pbocUserPassword = pbocUserPassword;
    }

    public String getBankCode() {
        return this.bankCode;
    }

    public void setBankCode(final String bankCode) {
        this.bankCode = bankCode;
    }

    public String getInstCode() {
        return this.instCode;
    }

    public void setInstCode(final String instCode) {
        this.instCode = instCode;
    }

    public String getEnqueryLoc() {
        return this.enqueryLoc;
    }

    public void setEnqueryLoc(final String enqueryLoc) {
        this.enqueryLoc = enqueryLoc;
    }

    public String getResultCode() {
        return this.resultCode;
    }

    public void setResultCode(final String resultCode) {
        this.resultCode = resultCode;
    }

    public String getYlzd1() {
        return this.ylzd1;
    }

    public void setYlzd1(final String ylzd1) {
        this.ylzd1 = ylzd1;
    }

    public String getYlzd2() {
        return this.ylzd2;
    }

    public void setYlzd2(final String ylzd2) {
        this.ylzd2 = ylzd2;
    }

    public String getYlzd3() {
        return this.ylzd3;
    }

    public void setYlzd3(final String ylzd3) {
        this.ylzd3 = ylzd3;
    }

    public String getYlzd4() {
        return this.ylzd4;
    }

    public void setYlzd4(final String ylzd4) {
        this.ylzd4 = ylzd4;
    }

    public String getYlzd5() {
        return this.ylzd5;
    }

    public void setYlzd5(final String ylzd5) {
        this.ylzd5 = ylzd5;
    }

    public String getSyjg() {
        return this.syjg;
    }

    public void setSyjg(final String syjg) {
        this.syjg = syjg;
    }

    public String getCurrentActor() {
        return this.currentActor;
    }

    public void setCurrentActor(final String currentActor) {
        this.currentActor = currentActor;
    }
}
