// package com.shawn.local.test;
//
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.IdentityHashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.ExecutorService;
// import java.util.concurrent.Executors;
// import java.util.concurrent.Future;
//
// import org.springframework.context.ApplicationContext;
// import
// org.springframework.context.annotation.AnnotationConfigApplicationContext;
// import org.springframework.data.mongodb.core.MongoTemplate;
// import org.springframework.data.mongodb.core.query.Criteria;
// import org.springframework.data.mongodb.core.query.Query;
//
// import com.alibaba.fastjson.JSON;
// import com.alibaba.fastjson.TypeReference;
//
// import net.sf.json.JSONObject;
//
/// **
// * @author Shawn.wang
// * @create Apr 23, 2018 2:35:19 PM
// */
// public class TestMogo {
//
// public static void queryApplicationByMutiValue(final MongoTemplate
// mongoTemplate,
// final Map<String, Object> equalsMap, final Map<String, List<Object>> ormap) {
// Query query = new Query();
// Criteria criteriaAll = new Criteria();
// List<Criteria> criteriaList = new ArrayList<Criteria>();
// for (Map.Entry<String, Object> entry : equalsMap.entrySet()) {
// Criteria tempCriteria = Criteria.where(entry.getKey()).is(entry.getValue());
// criteriaList.add(tempCriteria);
// }
//
// Criteria orCriteria = new Criteria();
// for (Map.Entry<String, List<Object>> entry : ormap.entrySet()) {
// List<Object> values = (List<Object>) entry.getValue();
// orCriteria = Criteria.where(entry.getKey()).in(values);
// criteriaList.add(orCriteria);
// }
//
// Criteria[] equalCriteriaArr = (Criteria[]) criteriaList.toArray(new
// Criteria[0]);
//
// criteriaAll.andOperator(equalCriteriaArr);
//
// query.addCriteria(criteriaAll);
// LoanApplication r = mongoTemplate.findOne(query, LoanApplication.class);
// if (null != r) {
// System.out.println(r.toString());
// }
// }
//
// public static void test1(final MongoTemplate mongoTemplate) {
// Query query = new Query();
// Criteria criteria = Criteria.where("companyInfo.socialCreditCode").is("66");
// query.addCriteria(criteria);
// LoanApplication result = mongoTemplate.findOne(query, LoanApplication.class);
// System.out.println(result.get_id());
// result.setTokenId("updateTest");
// result.setCountryCode("CCC");
// mongoTemplate.save(result);
// }
//
// public static void test2(final MongoTemplate mongoTemplate) {
// Map<String, Object> equalsMap = new HashMap<String, Object>();
// equalsMap.put("referralId", "22222222");
// equalsMap.put("companyInfo.socialCreditCode", "555555");
//
// List<Object> values = new ArrayList<>();
// values.add(2);
// values.add(1);
//
// List<Object> value2 = new ArrayList<>();
// value2.add(2);
// value2.add(1);
//
// Map<String, List<Object>> ormap = new IdentityHashMap<String,
// List<Object>>();
// ormap.put(new String("status"), values);
// ormap.put(new String("emailStatus"), value2);
//
// queryApplicationByMutiValue(mongoTemplate, equalsMap, ormap);
// }
//
// public static void test3(final MongoTemplate mongoTemplate) {
// Query query = new Query();
//
// Map<String, Object> equalsMap = new HashMap<String, Object>();
// equalsMap.put("referralId", "referralId");
// equalsMap.put("companyInfo.socialCreditCode", "91440113724306988J");
//
// for (Map.Entry<String, Object> entry : equalsMap.entrySet()) {
// Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
// query.addCriteria(criteria);
// }
// LoanApplication re = mongoTemplate.findOne(query, LoanApplication.class);
// if (null != re) {
// System.out.println(re.get_id());
// }
// }
//
// public static void test4(final MongoTemplate mongoTemplate) {
// // String result = HttpClientUtil.getData();
// // JSONObject obj = JSONObject.fromObject(result);
// // DBObject obj = (DBObject) JSON.parse(result);
//
// String testStr = "{\"test\":{\"aa\":\"bb\"}}";
// TestInsert test = new TestInsert();
// test.setInsertTime(System.currentTimeMillis());
// // test.setSrcData(obj);
// test.setResponseData(testStr);
//
// mongoTemplate.save(test);
// // mongoTemplate.save(obj);
//
// test.setResponseData("{\"test\":{\"cccc\":\"bb\"}}");
// mongoTemplate.save(test);
// // mongoTemplate.upsert(query, update, TestInsert.class);
//
// test.setResponseData("{\"test\":{\"ddd\":\"bb\"}}");
// mongoTemplate.save(test);
//
// // mongoTemplate.upsert(newQuery(Criteria.where("onumber").is("001")),
// // newUpdate().set("cname", "zcy"), collectionName);
//
// }
//
// public static void test5(final MongoTemplate mongoTemplate) {
// // mongoTemplate.updateFirst(
// // new
// //
// Query(Criteria.where("status").is(ApplicationStatus.RECEIVED).where("lastUpdateDate").is("20180418154358")),
// // new Update().set("countryCode", "OK"), LoanApplication.class);
//
// int test = 2;
// Map<String, Object> testdata = new HashMap<String, Object>();
// testdata.put("status", test);
// testdata.put("lastUpdateDate", "20180418154358");
//
// Query query = new Query();
// for (Map.Entry<String, Object> entry : testdata.entrySet()) {
// Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
// query.addCriteria(criteria);
// }
// LoanApplication loanApplication = mongoTemplate.findOne(query,
// LoanApplication.class);
// loanApplication.setCountryCode("OK");
// // loanApplication.getCompanyInfo().setSendType(1);
// mongoTemplate.save(loanApplication);
//
// // TestInsert dd = mongoTemplate.findOne(query, TestInsert.class);
// // System.out.println(dd.getResponseData());
// // dd.setResponseData("just update 2");
// // mongoTemplate.save(dd);
//
// }
//
// public static void test6(final MongoTemplate mongoTemplate, final long total)
// {
// LoanApplication lendingInfo = ApplicationServiceTest.getLendingInfo();
// QianhaiInfo qianhaiInfo = new QianhaiInfo();
// qianhaiInfo.setEntName("中国飞机制造厂");
// qianhaiInfo.setEntType("有限责任公司");
// qianhaiInfo.setIndustryName("制造产业");
// // qianhaiInfo.setProvince("上海市");
// qianhaiInfo.setUserName("张玉良");
// // qianhaiInfo.setBusiScope1("飞机制造");
// qianhaiInfo.setRegNo("regno");
// List<HolderInc> hl = new ArrayList<HolderInc>();
// for (int i = 0; i < 15; i++) {
// HolderInc t = new HolderInc();
// t.setConDate("2009-06-09");
// t.setConRate("32.61%");
// t.setSubAmt("32.610000");
// t.setUserName("胡志荣");
// hl.add(t);
// }
// qianhaiInfo.setHolderIncs(hl);
// qianhaiInfo.setAddress("东莞市中堂镇蕉利管理区沉塘村冲口工业区");
// qianhaiInfo.setEntType("有限责任公司(自然人投资或控股)");
// qianhaiInfo.setCoCode("335");
// qianhaiInfo.setCoName("建筑、安全用金属制品制造");
// qianhaiInfo.setRegOrg("东莞市工商行政管理局");
//
// List<HisChangeInc> hisChangeInc = new ArrayList<HisChangeInc>();
// for (int i = 0; i < 15; i++) {
// HisChangeInc t = new HisChangeInc();
// t.setChangeAfter("黄若文,执行董事,经理；魏世贵,监事");
// t.setChangeBefore("曹海满,执行董事,经理；魏世贵,监事");
// t.setChangeItem("投资人(股权)变更");
// t.setChangeDate("2010-09-19");
// hisChangeInc.add(t);
// }
// qianhaiInfo.setHisChangeIncs(hisChangeInc);
//
// List<LegOtherDutyInc> legOtherDutyIncs = new ArrayList<LegOtherDutyInc>();
// for (int i = 0; i < 10; i++) {
// LegOtherDutyInc t = new LegOtherDutyInc();
// t.setDutyInc("执行董事兼总经理");
// t.setEntName("广州市凯思勒新材料科技有限公司");
// t.setFrName("胡志荣");
// t.setRegNo("440108000087696");
// t.setRevokeDate("123323");
// legOtherDutyIncs.add(t);
// }
// qianhaiInfo.setLegOtherDutyIncs(legOtherDutyIncs);
//
// lendingInfo.setQianHaiInfo(qianhaiInfo);
//
// List<Stakeholder> shareHolders = new ArrayList<Stakeholder>();
// for (int i = 0; i < 8; i++) {
// Stakeholder sh = new Stakeholder();
// sh.setBankCardId("666688889995");
// sh.setCellphone("150369874544");
// sh.setNationality("中国");
// sh.setGuarantor(true);
// sh.setLegalRepresentative(true);
// sh.setPercentOfEquity("30%");
// sh.setIdCardNumber("6103696456134968797");
// // sh.setAddress("张三地址'");
// sh.setBirthday("1999-12-01");
// sh.setName("李四");
// sh.setValidityPeriodBegin("2010.09.09");
// sh.setValidityPeriodEnd("2040.09.09");
// sh.setIssuingAuthority("西安市公安局");
// sh.setIdCardType("中国居民身份证");
// sh.setIdCardFace("http://xxxxxxxxFacejpg");
// sh.setIdCardBack("http://xxxxxxxxBack.jpg");
// sh.setFirstName("志荣");
// sh.setLastName("胡");
// sh.setBlacklist(0);
// shareHolders.add(sh);
// }
//
// lendingInfo.setStakeholder(shareHolders);
// // List<DocumentLinks> dd = new ArrayList<DocumentLinks>();
// // for (int i = 0; i < 8; i++) {
// // DocumentLinks a = new DocumentLinks();
// // a.setBatchId("aaaaaaaaaaa");
// // a.setName("这是文件名称");
// // a.setFileName("faaaaa.jgp");
// // dd.add(a);
// // }
// // lendingInfo.setDocumentLinks(dd);
// for (int i = 0; i < total; i++) {
// try {
// Thread.sleep(20);
// } catch (InterruptedException e) {
// e.printStackTrace();
// }
// if (null != lendingInfo.get_id()) {
// lendingInfo.set_id(null);
// }
// try {
// mongoTemplate.save(lendingInfo);
// } catch (Exception e) {
// System.out.println(e.getMessage());
// }
// System.out.println("insert " + i + " ok");
// }
//
// }
//
// public static void test8(final MongoTemplate mongoTemplate, final
// LoanApplication info) {
// mongoTemplate.save(info);
// }
//
// public static void test7(final MongoTemplate mongoTemplate) throws
// InterruptedException {
//
// ExecutorService executorService = Executors.newFixedThreadPool(3);
//
// LoanApplication loan = new LoanApplication();
// loan.setCountryCode("ttt");
//
// Task t1 = new Task(loan, mongoTemplate, "task1");
// Task t2 = new Task(loan, mongoTemplate, "task2");
// Task t3 = new Task(loan, mongoTemplate, "task3");
//
// List<Future<String>> resultList = new ArrayList<Future<String>>();
// Future<String> future1 = executorService.submit(t1);
// Thread.sleep(1000);
// Future<String> future2 = executorService.submit(t2);
// Future<String> future3 = executorService.submit(t3);
// executorService.shutdown();
//
// resultList.add(future1);
// resultList.add(future2);
// resultList.add(future3);
//
// System.out.println("===========result =========");
// for (Future<String> fs : resultList) {
// try {
// System.out.println(" result is " + fs.get());
// } catch (ExecutionException e) {
// e.printStackTrace();
// }
// }
// System.out.println("===========result2 =========");
//
// }
//
// public static void test9(MongoTemplate mongoTemplate) throws Exception {
// Map<String, Object> testdata = new HashMap<String, Object>();
// testdata.put("bizId", "111");
//
// Query query = new Query();
// for (Map.Entry<String, Object> entry : testdata.entrySet()) {
// Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
// query.addCriteria(criteria);
// }
// Object re = mongoTemplate.findOne(query, Object.class);
// System.out.println(re.toString());
// }
//
// public static void test10(MongoTemplate mongoTemplate) throws Exception {
// Map<String, Object> testdata = new HashMap<String, Object>();
// // testdata.put("documentBatch.documents", null);
// testdata.put("documentBatch.documents.documentTitle", "111");
//
// Query query = new Query();
// for (Map.Entry<String, Object> entry : testdata.entrySet()) {
// Criteria criteria = Criteria.where(entry.getKey()).is(entry.getValue());
// query.addCriteria(criteria);
// }
// // LoanApplication re = mongoTemplate.findOne(query,
// // LoanApplication.class);
// List<LoanApplication> re = mongoTemplate.find(query, LoanApplication.class);
//
// System.out.println(re.size());
// }
//
// public static void test11(MongoTemplate mongoTemplate) throws Exception {
//
// Query query = new Query();
// // name 以 c结尾的
// query.addCriteria(Criteria.where("name").regex("c$"));
//
// // 以A开头的
// // query.addCriteria(Criteria.where("name").regex("^A"));
//
// // LoanApplication re = mongoTemplate.findOne(query,
// // LoanApplication.class);
// List<LoanApplication> re = mongoTemplate.find(query, LoanApplication.class);
//
// System.out.println(re.size());
// }
//
// public static void test12(MongoTemplate mongoTemplate) throws Exception {
//
// // LoanApplication a = new LoanApplication();
// // a.setTokenId("tt2");
// // CompanyInfo c = new CompanyInfo();
// // BizContact b = new BizContact();
// // c.setBizContact(b);
// // a.setCompanyInfo(c);
// // mongoTemplate.save(a);
//
// Query query = new Query();
// query.addCriteria(Criteria.where("_id").is("5b4814aa2a47dc1d60cd96c2"));
// ArchiveIndividualBureau aib = mongoTemplate.findOne(query,
// ArchiveIndividualBureau.class);
// JSONObject bb = JSONObject.fromObject(aib.getObj());
// System.out.println(bb.getJSONObject("response"));
// CreditReortResponse response =
// JSON.parseObject(bb.getJSONObject("response").toString(),
// new TypeReference<CreditReortResponse>() {
// });
// System.out.println(response.getRecordDetail());
//
// }
//
// public static void test13(MongoTemplate mongoTemplate) throws Exception {
//
// ArchiveIndividualBureau archiveIndividualBureau = new
// ArchiveIndividualBureau();
// archiveIndividualBureau.setObj(HttpClientUtil.getDataPost());
// mongoTemplate.save(archiveIndividualBureau);
//
// }
//
// public static void main(final String[] args) throws Exception {
// // For Annotation
// ApplicationContext ctx = new
// AnnotationConfigApplicationContext(SpringMongoConfig.class);
// // MongoOperations mongoTemplate = (MongoOperations)
// // ctx.getBean("mongoTemplate");
// MongoTemplate mongoTemplate = (MongoTemplate) ctx.getBean("mongoTemplate");
//
// // test3(mongoTemplate);
// // test4(mongoTemplate);
//
// // test5(mongoTemplate);
// //
// // long total = Long.valueOf(args[0]);
// // System.out.println(" test " + total);
// // test6(mongoTemplate, total);
//
// // test7(mongoTemplate);
// // test9(mongoTemplate);
// // test10(mongoTemplate);
// test12(mongoTemplate);
//
// // test13(mongoTemplate);
//
// }
//
// static class TestInsert {
// private String _id;
// private long insertTime;
// private JSONObject srcData;
// private String responseData;
//
// public String get_id() {
// return this._id;
// }
//
// public void set_id(final String _id) {
// this._id = _id;
// }
//
// public String getResponseData() {
// return this.responseData;
// }
//
// public void setResponseData(final String responseData) {
// this.responseData = responseData;
// }
//
// public long getInsertTime() {
// return this.insertTime;
// }
//
// public void setInsertTime(final long insertTime) {
// this.insertTime = insertTime;
// }
//
// public JSONObject getSrcData() {
// return this.srcData;
// }
//
// public void setSrcData(final JSONObject srcData) {
// this.srcData = srcData;
// }
//
// }
// }
