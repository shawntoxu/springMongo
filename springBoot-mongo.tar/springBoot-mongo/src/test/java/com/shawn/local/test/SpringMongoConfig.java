package com.shawn.local.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.Mongo;

@Configuration
public class SpringMongoConfig extends AbstractMongoConfiguration {

    @Override
    public @Bean
    Mongo mongo() throws Exception {

        return new Mongo("127.0.0.1");
    }

    @Override
    public @Bean
    MongoTemplate mongoTemplate() throws Exception {

        return new MongoTemplate(mongo(), "cadabra");
    }

    @Override
    protected String getDatabaseName() {
        // TODO Auto-generated method stub
        return "cadabra";
    }

}