package com.shawn.local.test;

import java.lang.reflect.Field;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author Shawn.wang
 * @version May 22, 2018 2:07:02 PM
 */
/**
 * <p>
 * <b> filter all api request from frontend </b>
 * </p>
 */
public class SystemInterceptor implements HandlerInterceptor {
	private Logger LOGGER = LoggerFactory.getLogger(SystemInterceptor.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.
	 * servlet .http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object)
	 */
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
			throws Exception {
		this.LOGGER.info("=================controller before=================");
		Map<String, String[]> map = request.getParameterMap();
		String[] appid = { "appid" };
		Field lockedField = map.getClass().getDeclaredField("locked");
		lockedField.setAccessible(true);
		// set lockedField to false to modify attribute
		lockedField.setBoolean(map, false);
		map.put("appId", appid);
		lockedField.setBoolean(map, true);

		// String requestBody = IOUtils.toString(request.getInputStream(),
		// "UTF-8");
		// this.LOGGER.info("request body === {}", requestBody);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.
	 * servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object, org.springframework.web.servlet.ModelAndView)
	 */
	public void postHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler,
			final ModelAndView modelAndView) throws Exception {
		this.LOGGER.info("=================controller completed=================");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#afterCompletion(javax
	 * .servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object, java.lang.Exception)
	 */
	public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response,
			final Object handler, final Exception ex) throws Exception {

	}

}
