package com.shawn.local.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import com.test.app.util.DataSecurityUtil;

/**
 * @author Shawn.wang
 * @version Jun 6, 2018 2:56:14 PM
 */
public class TT {

	public static void getEntiry() {
		Map<String, String> plaintextObj = new HashMap<String, String>();
		plaintextObj.put("phoneNumber", "13552535506");
		plaintextObj.put("REQUEST_ID", "REQUEST_ID");
		plaintextObj.put("GUID", "GUID");

		String encryptData = DataSecurityUtil.encrypt(plaintextObj);
		System.out.println(encryptData);
	}

	public static void getEntiryPhone() {

		String encryptData = DataSecurityUtil.encrypt("12345678911");
		System.out.println(encryptData);
	}

	public static void getDate() {
		long t = 1532049738759L;
		long t2 = t + 300 * 1000;
		System.out.println(t2 - t);
		SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd HH:mm:SS");
		sf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
		String ss = sf.format(new Date(t));
		String ss2 = sf.format(new Date(t2));

		System.out.println(ss);
		System.out.println(ss2);

	}

	// public static void loadProperties(Properties pro) {
	// String value = pro.getProperty("udspsdk.QueryUrl");
	// if (!SDKUtil.isEmpty(value))
	// QueryUrl = value.trim();
	// value = pro.getProperty("udspsdk.SendUrl");
	// if (!SDKUtil.isEmpty(value))
	// sendUrl = value.trim();
	// value = pro.getProperty("udspsdk.signCert.path");
	// if (!SDKUtil.isEmpty(value))
	// signCertPath = value.trim();
	// value = pro.getProperty("udspsdk.signCert.pwd");
	// if (!SDKUtil.isEmpty(value))
	// signCertPwd = value.trim();
	// value = pro.getProperty("udspsdk.signCert.type");
	// if (!SDKUtil.isEmpty(value))
	// signCertType = value.trim();
	// value = pro.getProperty("udspsdk.encryptCert.path");
	// if (!SDKUtil.isEmpty(value))
	// encryptCertPath = value.trim();
	// value = pro.getProperty("udspsdk.acpVerifyCert.path");
	// if (!SDKUtil.isEmpty(value))
	// acpVerifyCertPath = value.trim();
	// value = pro.getProperty("udspsdk.insVerifyCert.path");
	// if (!SDKUtil.isEmpty(value))
	// insVerifyCertPath = value.trim();
	// }

	public static void main(String[] args) {
		// System.out.println(UUID.randomUUID().toString());
		// CbaCategory c = new CbaCategory();
		//
		// System.out.println(JSONObject.fromObject(c).toString());
		//

		// String[] ss = { "aaa", "bb" };

		// boolean test = false;
		// if (!test) { // test == false
		// System.out.println("run");
		// }

		// char a = '1';
		// String t = String.valueOf(a);
		// System.out.println(t);

		// BigDecimal bg = new BigDecimal("0.00");
		// BigDecimal t1 = new BigDecimal("1");
		// bg = bg.add(t1);
		// System.out.println(bg);
		//
		// System.out.println(JSONObject.fromObject("{\"a\":\"b\"}").toString());
		// System.out.println(JSONObject.fromObject(null).toString());
		// getDate();
		// getEntiry();

		// InputStream in =
		// SDKConfig.class.getClassLoader().getResourceAsStream("udsp_sdk.properties");
		// Properties properties = new Properties();
		// try {
		// properties.load(in);
		// } catch (IOException e) {
		// }

		// getDate();

		// getEntiry();
		getEntiryPhone();
	}
}
