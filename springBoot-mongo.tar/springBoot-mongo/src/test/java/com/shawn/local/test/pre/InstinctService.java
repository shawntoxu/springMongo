// package com.shawn.local.test.pre;
//
// import org.springframework.stereotype.Service;
//
//
//
// @Service
// public interface InstinctService<T> extends AsyncTask<T> {
// public void sendInstinctData(LoanApplication loanApp, T t);
// }
