package com.shawn.local.test;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.test.app.util.HttpClientUtil;

import net.sf.json.JSONObject;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class GetYinlianData {

	public void test() throws Exception {
		// restTemplateTool
		CreditReportRequest re = new CreditReportRequest();
		re.setCertno("341200198812101450");
		re.setName("张三");
		re.setBankCode("0321");
		re.setInstCode("032104");
		re.setCerttype("0");
		re.setPbocUserName("010738");
		re.setPbocUserPassword("12345678");
		re.setQueryReason("01");
		re.setShenqingjianNo("987654321");
		re.setSystem("SYS");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

	}

	public static void test2() {
		// ApplicationContext ctx = new
		// ClassPathXmlApplicationContext("request-proxy.xml");
		// ApplicationContext ctx = new
		// FileSystemXmlApplicationContext("src/main/resources/request-proxy.xml");

		// String path =
		// //
		// "C:/Users/44106875/Desktop/work/Top/java/eclipse_space/cn-cadabra-seller-loan-application-api/src/main/resources/request-proxy.xml";
		// String path = "C:/Users/44106875/Desktop/test/request-proxy.xml";

		// ApplicationContext ctx = new FileSystemXmlApplicationContext(path);

		// RestTemplate restTemplate = (RestTemplate)
		// ctx.getBean("RestTemplate");

		RestTemplate restTemplate = new RestTemplate();
		CreditReportRequest re = new CreditReportRequest();
		re.setCertno("341200198812101450");
		re.setName("张三");
		re.setBankCode("0321");
		re.setInstCode("032104");
		re.setCerttype("0");
		re.setPbocUserName("010738");
		re.setPbocUserPassword("12345678");
		re.setQueryReason("01");
		re.setShenqingjianNo("987654321");
		re.setSystem("CCAM");

		Map<String, String> maps = new HashMap<String, String>();
		maps.put("bankCode", "0321");
		maps.put("instCode", "032104");
		maps.put("name", "张三");
		maps.put("pbocUserName", "010738");
		maps.put("pbocUserPassword", "12345678");
		maps.put("certno", "341200198812101450");
		maps.put("certtype", "0");
		maps.put("queryReason", "01");
		maps.put("shenqingjianNo", "987654321");
		maps.put("system", "CCAM");

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String url2 = "http://172.26.204.93:58084/UIBS/personal/jsonCredit";

		final HttpEntity<JSONObject> httpEntity = new HttpEntity<JSONObject>(JSONObject.fromObject(re), headers);
		// final HttpEntity<Map<String,String>> httpEntity = new
		// HttpEntity<JSONObject>(JSONObject.fromObject(re), headers);

		ResponseEntity<String> response = restTemplate.exchange(url2, HttpMethod.POST, httpEntity, String.class);
		System.out.println("==========result is =========");
		System.out.println(response.toString());
	}

	public static void main(final String[] args) {

		String url2 = "http://tttt:9039/api/ea/v1/aws/application/received";
		// RestTemplate restTemplate = new RestTemplate();
		//
		// Map<String, String> request = new HashMap<String, String>();
		// request.put("tokenId", "AZUI1234POIL");
		// request.put("referralId", "ZIOUY11111");
		// request.put("detailedStatus", "");
		// HttpHeaders headers = new HttpHeaders();
		// headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		//
		//
		// final HttpEntity<JSONObject> httpEntity = new
		// HttpEntity<JSONObject>(JSONObject.fromObject(request), headers);
		// // final HttpEntity<Map<String,String>> httpEntity = new
		// // HttpEntity<JSONObject>(JSONObject.fromObject(re), headers);
		//
		// ResponseEntity<String> response = restTemplate.exchange(url2,
		// HttpMethod.POST, httpEntity, String.class);
		// System.out.println("==========result is =========");
		// System.out.println(response.toString());

		Map<Object, Object> request2 = new HashMap<Object, Object>();
		request2.put("tokenId", "t");
		request2.put("referralId", "r");
		request2.put("detailedStatus", "");
		// String result = restTemplate.postForObject(url2, request2,
		// String.class);

		String responseContent = HttpClientUtil.getInstance().sendHttpPost(url2, request2);
		System.out.println(responseContent);

	}
}
