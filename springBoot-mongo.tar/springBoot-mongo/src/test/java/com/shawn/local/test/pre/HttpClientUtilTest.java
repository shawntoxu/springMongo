// package com.shawn.local.test.pre;
//
// import java.util.HashMap;
// import java.util.Map;
//
// import org.junit.Test;
//
// import com.shawn.local.test.HttpClientUtil;
//
/// **
// * @author Shawn.wang
// * @version May 5, 2018 4:15:37 PM
// */
//
// public class HttpClientUtilTest {
//
// @Test
// public void test() {
// String url2 = "http://172.26.204.93:58084/UIBS/personal/jsonCredit";
// Map<String, String> maps = new HashMap<String, String>();
// maps.put("bankCode", "0321");
// maps.put("instCode", "032104");
// maps.put("name", "张三");
// maps.put("pbocUserName", "010738");
// maps.put("pbocUserPassword", "12345678");
// maps.put("certno", "341200198812101450");
// maps.put("certtype", "0");
// maps.put("queryReason", "01");
// maps.put("shenqingjianNo", "987654321");
// maps.put("system", "CCAM");
// String responseContent = HttpClientUtil.getInstance().sendHttpPost(url2,
/// maps);
// }
//
// }
