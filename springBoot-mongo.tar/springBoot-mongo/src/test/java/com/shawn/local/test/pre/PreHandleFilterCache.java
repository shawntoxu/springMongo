// package com.shawn.local.test.pre;
//
// import java.io.IOException;
//
// import javax.servlet.Filter;
// import javax.servlet.FilterChain;
// import javax.servlet.FilterConfig;
// import javax.servlet.ServletException;
// import javax.servlet.ServletRequest;
// import javax.servlet.ServletResponse;
// import javax.servlet.http.HttpServletRequest;
//
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.core.Ordered;
// import org.springframework.core.annotation.Order;
// import org.springframework.stereotype.Component;
//
//
// @Component
// @Order(Ordered.HIGHEST_PRECEDENCE)
// public class PreHandleFilterCache implements Filter {
// private Logger LOGGER = LoggerFactory.getLogger(PreHandleFilterCache.class);
//
// @Autowired
// private CacheService cacheService;
//
// public void init(final FilterConfig filterConfig) throws ServletException {
// }
//
// public void doFilter(final ServletRequest request, final ServletResponse
/// response, final FilterChain chain)
// throws IOException, ServletException {
// final HttpServletRequest httpRequest = (HttpServletRequest) request;
// // matched /api/ea/v1/applications/{unifiedSocialCreditCode}/existance
// if (null != httpRequest.getRequestURI() &&
/// httpRequest.getRequestURI().indexOf("existance") != -1
// && httpRequest.getRequestURI().split("/").length == 7) {
// String ucs = httpRequest.getRequestURI().split("/")[5];
// if (ValidateUtil.isUnifiedSocialCreditCode(ucs)) {
// this.LOGGER.info(
// " matched [ /api/ea/v1/applications/{unifiedSocialCreditCode}/existance ] url
/// = {} ,will do preQuery ",
// httpRequest.getRequestURI());
// new Thread(new CacheTask(this.cacheService, ucs)).start();
// }
//
// }
//
// chain.doFilter(request, response);
// }
//
// public void destroy() {
// }
//
// private class CacheTask implements Runnable {
// private CacheService cahceService;
// private String[] query;
//
// public CacheTask(final CacheService cahceService, final String... query) {
// this.cahceService = PreHandleFilterCache.this.cacheService;
// this.query = query;
// }
//
// public void run() {
// try {
// PreHandleFilterCache.this.LOGGER.info(" pre query begin");
// String socialCreditCode = this.query[0];
// // String idcardNum = this.query[1];
// // String legalName = this.query[2];
// this.cahceService.preQuery(null, null, socialCreditCode);
// PreHandleFilterCache.this.LOGGER.info(" pre query end");
// } catch (Exception e) {
// }
// }
//
// }
//
// }
