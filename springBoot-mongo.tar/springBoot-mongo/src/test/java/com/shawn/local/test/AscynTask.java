package com.shawn.local.test;

/**
 * @author Shawn.wang
 * @version Jun 28, 2018 11:52:27 AM
 */
public class AscynTask {

	public static void main(String[] args) {

	}

}
