// package com.shawn.local.test.pre;
//
// import java.text.SimpleDateFormat;
// import java.util.Date;
// import java.util.HashMap;
// import java.util.Map;
//
// import javax.annotation.PostConstruct;
//
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Qualifier;
// import org.springframework.context.annotation.Profile;
// import org.springframework.core.env.Environment;
// import org.springframework.stereotype.Service;
// import org.springframework.web.client.RestClientException;
//
// import com.alibaba.fastjson.JSON;
// import com.alibaba.fastjson.JSONArray;
// import com.alibaba.fastjson.JSONObject;
// import com.unionpay.udsp.sdk.CertUtil;
// import com.unionpay.udsp.sdk.SDKConfig;
// import com.unionpay.udsp.sdk.SDKConstants;
// import com.unionpay.udsp.sdk.SDKUtil;
// import com.unionpay.udsp.sdk.SecureUtil;
//
/// **
// * <p>
// * <b> Cup Factor Service Impl </b>
// * </p>
// */
// @Service
// @Profile({ "LOCAL", "Test", "PROD" })
// public class CupFactorServiceImpl implements CupFactorService {
// private Logger logger = LoggerFactory.getLogger(this.getClass());
// private static Map<String, String> commonData = new HashMap<String,
/// String>();
// private final String CARD_ATTR_DEBIT = "01";
// private final String CARD_BRAND_UNION62 = "1";
// private final String CARD_BRAND_UNION6 = "2";
// private final String CARD_BRAND_UNION9 = "3";
//
// @Autowired
// private RestTemplateUtil restTemplateUtil;
//
// @Autowired
// @Qualifier("proxyFactory")
// private TrustAllClientHttpRequestFactory proxyFactory;
//
// @Autowired
// private CUPConfig cupConfig;
//
// @Autowired
// private CUP4ElementsDao cup4ElementsDao;
//
// @Autowired
// private Environment environment;
//
// @PostConstruct
// public void init() {
// String appId = this.cupConfig.getAppId();
// String appKey = this.cupConfig.getAppKey();
// CupFactorServiceImpl.commonData.put(SDKConstants.key_encoding,
/// SDKConstants.encoding_UTF_8);
// CupFactorServiceImpl.commonData.put(SDKConstants.key_certId,
/// CertUtil.getSignCertId());
// CupFactorServiceImpl.commonData.put(SDKConstants.key_version,
/// SDKConstants.version_1);
// CupFactorServiceImpl.commonData.put(SDKConstants.key_signMethod,
/// SDKConstants.signMethod_RSA_SHA);
// CupFactorServiceImpl.commonData.put(SDKConstants.key_appId, appId);
// CupFactorServiceImpl.commonData.put(SDKConstants.key_appKey, appKey);
// }
//
// @Loggable
// public CupFactorResponse validateCUPFactor(final CupFactorRequest
/// customerInfo) {
// CupFactorResponse response = new CupFactorResponse();
// String idCardNumber = customerInfo.getCertifId();
//
// // failed times > 5, return error
// boolean condition = lookupCondition(idCardNumber);
// if (condition == false) {
// response.setRespCode(ResponseCode.CUP_ELEMENT_FAILED_5TIMES.getCode());
// response.setRespMsg("more than 5 times");
// return response;
// }
//
// // set request value
// String cupRequestData = this.prepareCupRequestData(customerInfo);
// logger.debug("send cup4 request data:{}", cupRequestData);
// try {
// String resp = null;
// if (CommonUtil.isRunLocal(this.environment.getActiveProfiles())) {
// resp =
/// this.restTemplateUtil.postJsonWithHttps(SDKConfig.getConfig().getQueryUrl(),
/// cupRequestData,
// null, true);
// } else {
// this.restTemplateUtil.setRequestFactory(this.proxyFactory);
// resp =
/// this.restTemplateUtil.postForObject(SDKConfig.getConfig().getQueryUrl(),
/// cupRequestData,
// String.class);
// }
// this.logger.info("cup response:{}", resp);
// response = this.parseCupResponseData(resp);
// if (response.getRespCode().equals(CUP4Elements.SUCCESS)) {
// removeRecord(idCardNumber);
// } else {
// addFailedTimes(idCardNumber);
// }
// } catch (Exception e) {
// addFailedTimes(idCardNumber);
// this.logger.error("request cup exception:{}", e.getMessage());
// response.setRespCode(CUP4Elements.CUP_EXCEPTION);
// response.setRespMsg(e.getMessage());
// }
//
// return response;
// }
//
// @Loggable
// public boolean validateCUP4Factors(final CupFactorRequest customerInfo) {
//
// String legalPersonBankCard = customerInfo.getCardNo();
// String idCardNumber = customerInfo.getCertifId();
// String name = customerInfo.getCustomerNm();
// String mobileNumber = customerInfo.getPhoneNo();
//
// this.logger.debug(" ================= validateCUP4Factors mobileNumber =
/// {},legalPersonBankCard ={} ",
// mobileNumber, legalPersonBankCard);
// this.logger.info("start to check 4 elements' legality");
// // if (!ValidateUtil.checkChineseName(name) ||
// // !CommonUtil.pureDigit(legalPersonBankCard, 16, 19)
// // || !CommonUtil.pureDigit(mobileNumber, 11, 13) ||
// // ValidateUtil.IDCardValidate(idCardNumber) != "") {
// // return false;
// // }
// if (!ValidateUtil.checkChineseName(name) ||
/// !CommonUtil.pureDigit(legalPersonBankCard, 16, 19)) {
// return false;
// }
//
// boolean condition = lookupCondition(idCardNumber);
// if (condition == false) {
// return false;
// }
//
// String cupRequestData = this.prepareCupRequestData(customerInfo);
// try {
// this.restTemplateUtil.setRequestFactory(this.proxyFactory);
// String response =
/// this.restTemplateUtil.postForObject(SDKConfig.getConfig().getQueryUrl(),
/// cupRequestData,
// String.class);
//
// // this.parseCupResponseData(response);
// if (checkResult(response)) {
// removeRecord(idCardNumber);
// return true;
// }
// } catch (RestClientException e) {
// addFailedTimes(idCardNumber);
// this.logger.error(e.getMessage());
// return false;
// }
// return false;
// }
//
// @Loggable
// public String prepareCupRequestData(final CupFactorRequest customerInfo) {
// String pCode = this.cupConfig.getpCode();
// Map<String, String> requestMap = new HashMap<String, String>();
// requestMap.putAll(CupFactorServiceImpl.commonData);
// requestMap.put(SDKConstants.key_orderId, SDKUtil.generateTxnTime());
// requestMap.put(SDKConstants.key_reqSeq, SDKUtil.generateTxnTime());
// requestMap.put(SDKConstants.key_reqTime, SDKUtil.generateTxnTime());
// requestMap.put(SDKConstants.key_pCode, pCode);
// // reqData
// Map<String, String> reqDataMap = new HashMap<String, String>();
// reqDataMap.put(SDKConstants.key_customerInfo, "[" +
/// JsonFormatterUtils.format(customerInfo) + "]");
//
// this.logger.info("[CUP Request] - Customer Information : " + reqDataMap);
// String reqData =
/// SecureUtil.encryptData(JsonFormatterUtils.format(reqDataMap),
/// SDKConstants.encoding_UTF_8,
// CertUtil.getEncryptCertPublicKey());
// requestMap.put(SDKConstants.key_reqData, reqData);
// SDKUtil.sign(requestMap, SDKConstants.encoding_UTF_8);
// String cupRequestData = JsonFormatterUtils.format(requestMap);
// this.logger.info("[CUP Request]" + cupRequestData);
//
// return cupRequestData;
// }
//
// private boolean checkResult(final String cupResponse) {
// this.logger.info("[CUP Response]" + cupResponse);
// CupFactorResponse cupValResp = new CupFactorResponse();
// if (!StringUtils.isBlank(cupResponse)) {
// Map<String, String> cupResponseMap =
/// SDKUtil.convertResultStringToMap(cupResponse);
// String respCode = cupResponseMap.get(SDKConstants.key_respCode);
// if (CUP4Elements.CUP_VERIFY_SUCCESS_CODE.equals(respCode)) {
// this.logger.info("cup4 check successful ");
// return true;
// }
// this.logger.info("cup4 check faild ,resonse code is {} ", respCode);
// }
// return false;
// }
//
// @Loggable
// public CupFactorResponse parseCupResponseData(final String cupResponse) {
// this.logger.info("[CUP Response]" + cupResponse);
// CupFactorResponse cupValResp = new CupFactorResponse();
// if (org.apache.commons.lang.StringUtils.isBlank(cupResponse)) {
// this.logger.error("CUP response empty.");
// cupValResp.setRespCode(CUP4Elements.CUP_EXCEPTION);
// cupValResp.setRespMsg("CUP response empty.");
// return cupValResp;
// }
//
// Map<String, String> cupResponseMap =
/// SDKUtil.convertResultStringToMap(cupResponse);
// String respCode = cupResponseMap.get(SDKConstants.key_respCode);
// cupValResp.setRespCode(respCode);
//
// if (!CUP4Elements.CUP_VERIFY_SUCCESS_CODE.equals(respCode)) {
// String errorMsg = cupResponseMap.get(SDKConstants.key_respMsg);
// this.logger.error("cup error message:{}", errorMsg);
// cupValResp.setRespCode(respCode);
// cupValResp.setRespMsg(errorMsg);
// return cupValResp;
// }
//
// boolean isOk = SDKUtil.validate(cupResponseMap, SDKConstants.encoding_UTF_8);
//
// if (!isOk) {
// this.logger.error("Validate CUP response false.");
// cupValResp.setRespCode(CUP4Elements.CUP_EXCEPTION);
// cupValResp.setRespMsg("validate CUP response failed.");
// return cupValResp;
// }
//
// String respData = cupResponseMap.get(SDKConstants.key_respData);
// JSONObject respDataJson = JSON.parseObject(respData);
// JSONArray cardDataList = respDataJson.getJSONArray("cardDataList");
// JSONObject oneCard = cardDataList.getJSONObject(0);
// String cardNo = oneCard.getString("cardNo");
// JSONObject cardData = oneCard.getJSONObject("cardData");
// String cardAttr = cardData.getString("c_card_attr_cd");
// String cardBrand = cardData.getString("c_card_brand_cd");
// String cardBank = cardData.getString("c_card_bank");
// cupValResp.setCardNo(cardNo);
// cupValResp.setCardBank(cardBank);
// cupValResp.setCardAttr(cardAttr);
// cupValResp.setCardBrand(cardBrand);
//
// if (!this.CARD_ATTR_DEBIT.equals(cardAttr)) {
// cupValResp.setRespCode(CUP4Elements.CUP_CARD_EXCEPTION);
// cupValResp.setRespMsg("validate CUP response failed.");
// return cupValResp;
// }
//
// if (!this.isCUPCard(cardBrand)) {
// cupValResp.setRespCode(CUP4Elements.CUP_CARD_EXCEPTION);
// cupValResp.setRespMsg("validate CUP response failed.");
// return cupValResp;
// }
// cupValResp.setRespCode(CUP4Elements.SUCCESS);
//
// return cupValResp;
// }
//
// public boolean isCUPCard(final String cardBrand) {
// String[] rbmCardArray = new String[] { this.CARD_BRAND_UNION62,
/// this.CARD_BRAND_UNION6,
// this.CARD_BRAND_UNION9 };
// return StringUtils.contains(rbmCardArray, cardBrand);
// }
//
// public boolean lookupCondition(final String idCardNumber) {
// Map<String, Object> map = new HashMap<String, Object>();
// map.put("idCardNumber", idCardNumber);
// CUP4ElementsModel obj = this.cup4ElementsDao.queryApplicationByKey(map);
//
// Date date = new Date();
// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
// String today = sdf.format(date);
//
// if (obj == null) {
// return true;
// } else if (obj.getFailedTimes() >= 5) {
// if (today.compareTo(obj.getFailedDay()) > 0) {
// this.cup4ElementsDao.removeObject(map);
// return true;
// } else {
// return false;
// }
// } else {
// return true;
// }
// }
//
// public void addFailedTimes(final String idCardNumber) {
// Date date = new Date();
// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
// String today = sdf.format(date);
//
// Map<String, Object> map = new HashMap<String, Object>();
// map.put("idCardNumber", idCardNumber);
// CUP4ElementsModel obj = this.cup4ElementsDao.queryApplicationByKey(map);
// if (obj != null) {
// int failedTimes = obj.getFailedTimes();
// obj.setFailedTimes(failedTimes + 1);
// obj.setFailedDay(today);
// } else {
// obj = new CUP4ElementsModel();
// obj.setFailedTimes(1);
// obj.setFailedDay(today);
// obj.setIdCardNumber(idCardNumber);
// }
//
// this.cup4ElementsDao.saveApplicationInfo(obj);
// }
//
// public void removeRecord(final String idCardNumber) {
// Map<String, Object> map = new HashMap<String, Object>();
// map.put("idCardNumber", idCardNumber);
//
// this.cup4ElementsDao.removeObject(map);
// }
// }
