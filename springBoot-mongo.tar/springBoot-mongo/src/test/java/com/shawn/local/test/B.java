package com.shawn.local.test;

import java.util.concurrent.Callable;

public class B implements Callable<String> {
    private long   sleep;
    private String name;

    public B(final long sleep, final String name) {
        this.sleep = sleep;
        this.name = name;
    }

    public String call() throws Exception {
        Thread.sleep(this.sleep);
        System.out.println(" run  over" + this.name);
        return this.name;
    }
}