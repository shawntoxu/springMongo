// package com.shawn.local.test.pre;
//
// import java.io.IOException;
// import java.nio.file.Files;
// import java.nio.file.Path;
// import java.nio.file.Paths;
// import java.nio.file.StandardOpenOption;
//
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestMethod;
// import org.springframework.web.bind.annotation.RestController;
//
// import sun.misc.BASE64Decoder;
//
// import com.test.app.constants.ResponseCode;
// import com.test.app.model.BaseResponse;
// import com.test.app.model.IdCard;
// import com.test.app.model.IdCardReq;
// import com.test.app.util.CommonUtil;
//
/// **
// * @author Shawn.wang
// * @version May 19, 2018 4:31:18 PM
// */
// @RestController
// @RequestMapping("/api/ea/v1/applications/idcard")
// public class IdCardUploadController {
//
// @RequestMapping(value = "/upload", method = RequestMethod.POST)
// public BaseResponse<IdCard> uploadIdCard(@RequestBody final IdCardReq
/// idCardReq) throws Exception {
// BaseResponse<IdCard> response = new BaseResponse<IdCard>();
//
// String idCardFaceData = idCardReq.getIdCardFaceData();
// String idCardBackData = idCardReq.getIdCardBackData();
// if (CommonUtil.checkObjFieldIsNull(idCardReq)) {
// response.setRespCode(ResponseCode.PARAM_ERROR);
// }
//
// byte[] idCardFacebyte = getImageByte(idCardFaceData);
// byte[] idCardBackbyte = getImageByte(idCardBackData);
//
// // test(idCardFacebyte);
// // test(idCardBackbyte);
//
// // call scan api
//
// return response;
// }
//
// private byte[] getImageByte(final String data) {
// BASE64Decoder decoder = new BASE64Decoder();
// try {
// byte[] imageByte = decoder.decodeBuffer(data);
// for (int j = 0; j < imageByte.length; ++j) {
// if (imageByte[j] < 0) {
// imageByte[j] += 256;
// }
// }
// return imageByte;
// } catch (IOException e) {
// e.printStackTrace();
// }
//
// return null;
// }
//
// private void test(final byte[] imageByte) {
// try {
// Path desPath = Paths.get("C:/Temp");
// desPath = desPath.resolve("mytest");
// if (!desPath.toFile().exists()) {
// desPath.toFile().mkdirs();
// }
// String desFileName = System.currentTimeMillis() + ".jpg";
// desPath = desPath.resolve(desFileName);
// Files.write(desPath, imageByte, StandardOpenOption.CREATE);
// } catch (IOException e) {
//
// }
// }
//
// }
