//
// import java.util.IdentityHashMap;
// import java.util.Map;
// import java.util.Map.Entry;
// import java.util.regex.Matcher;
// import java.util.regex.Pattern;
//
// import org.apache.commons.lang.StringUtils;
//
/// **
// * @author Shawn.wang
// * @version Apr 24, 2018 3:05:08 PM
// */
/// **
// public class Mytest {
// public static boolean isSpecialChar(final String str) {
// String regEx = "[
/// _`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]|\n|\r|\t";
// Pattern p = Pattern.compile(regEx);
// Matcher m = p.matcher(str);
// return m.find();
// }
//
// public static void testMap() {
// Map<String, Object> map = new IdentityHashMap<String, Object>();
// map.put(new String("key1"), "value1");
// map.put(new String("key1"), "value2");
// for (Entry<String, Object> entry : map.entrySet()) {
// System.out.print(entry.getKey() + " ");
// System.out.println(entry.getValue());
// }
// }
//
// public static void test3() {
// String testStr = ".";
// char[] test = { '&', '`' };
// System.out.println(StringUtils.indexOfAny(testStr, test));
// System.out.println(isSpecialChar(testStr));
//
// System.out.println(StringUtils.left("123456789", 4));
//
// System.out.println(ValidateUtil.isNumeric("R1316497978"));
//
// String result = DataSecurityUtil.encrypt("8615029996935");
// System.out.println(result);
// }
//
// public static void testToString() {
//
// ApplicationCreateInfoReq applicationCreateInfoReq = new
/// ApplicationCreateInfoReq();
// // applicationCreateInfoReq.setCountryCode("cccc");
// applicationCreateInfoReq.setTokenId("tid");
// applicationCreateInfoReq.setMobileNumber("mb");
// System.out.println(applicationCreateInfoReq.toString());
//
// }
//
// }
