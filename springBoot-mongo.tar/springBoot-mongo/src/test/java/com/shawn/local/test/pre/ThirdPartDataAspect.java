// package com.shawn.local.test.pre;
//
// import org.aspectj.lang.JoinPoint;
// import org.aspectj.lang.annotation.AfterReturning;
// import org.aspectj.lang.annotation.Aspect;
// import org.aspectj.lang.annotation.Before;
// import org.aspectj.lang.annotation.Pointcut;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.core.annotation.Order;
// import org.springframework.stereotype.Component;
//
//
// import net.sf.json.JSONObject;
//
/// **
// * @author Shawn.wang
// * @version Jun 29, 2018 3:19:41 PM
// */
// @Aspect
// @Order(-1)
// @Component
// public class ThirdPartDataAspect {
// private Logger LOGGER = LoggerFactory.getLogger(ThirdPartDataAspect.class);
//
// @Autowired
// private ThirdResponseDataDao thirdResponsDataDao;
//
// @Pointcut("execution(* *.*ByHttp(..))")
// public void DB() {
// }
//
// @Before("DB()")
// public void deBefore(JoinPoint point) throws Throwable {
// System.out.println("do----------------------------");
// }
//
// @AfterReturning(returning = "ret", pointcut = "DB()")
// public void doAfterReturning(JoinPoint point, Object ret) throws Throwable {
// Object[] args = point.getArgs(); // args
// Object object = args[0];
//
// String requestData = JSONObject.fromObject(object).toString();
// String responseData = JSONObject.fromObject(ret).toString();
// String requstAndResposn = "{requestData:" + requestData + "},{responseData:"
// + responseData + "}";
// long queryTime = System.currentTimeMillis();
// ThirdResponseData thridData = null;
// if (object instanceof CreditReportRequest) {
// CreditReportRequest creditReportRequest = (CreditReportRequest) object;
// thridData = new ArchiveIndividualBureau();
// if (null != creditReportRequest.getCertno()) {
// thridData.setBizId(creditReportRequest.getCertno());
// } else if (null != creditReportRequest.getName()) {
// thridData.setBizId(creditReportRequest.getName());
// }
// thridData.setAppId(args[1].toString());
// } else if (object instanceof InstinctRequest) {
// LoanApplication loanApp = (LoanApplication) args[1];
// thridData = new ArchiveInstinct();
// thridData.setBizId(loanApp.get_id());
// thridData.setAppId(loanApp.get_id());
// } else if (object instanceof CupFactorRequest) {
// CupFactorRequest cupFactorRequest = (CupFactorRequest) object;
// thridData = new ArchiveCup4();
// thridData.setBizId(cupFactorRequest.getCertifId());
// // this time , no appId
// }
// thridData.setObj(requstAndResposn);
// thridData.setQueryTime(queryTime);
// this.thirdResponsDataDao.saveApplicationInfo(thridData);
// // point.getTarget();// target
// LOGGER.debug(" request data : {} , response data {} ", responseData,
// responseData);
// }
//
// }
