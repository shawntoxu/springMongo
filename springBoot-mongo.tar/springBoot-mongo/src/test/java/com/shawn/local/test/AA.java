package com.shawn.local.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Shawn.wang
 * @version May 30, 2018 12:34:35 PM
 */
/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class AA {
	public static void main(final String[] args) {
		DateFormat fmt = new SimpleDateFormat("yyyy.MM.dd");

		try {
			Date date = fmt.parse("2018.01.01");
			System.out.println(fmt.format(date));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// String a =
		// "{\"decisioningServiceRequest\":{\"rusBody\":{\"externalSystemRequestDetails\":{\"dpsService405\":{\"serviceRequestPayload\":{\"dpsHeader\":{\"aliasName\":\"CN02AMP\",\"applicationid\":\"HBCNRBB\",\"requestFormat\":\"JSON\",\"requestType\":\"DECISIONING\",\"traceLevel\":\"31\",\"trackingId\":\"12345678901234500000\"},\"requestPayloadData\":{\"DAJSONDocument\":{\"CusInfo\":{\"BorrowerType\":{\"data_type\":\"text\",\"value\":\"003\"}},\"OCONTROL\":{\"ALIAS\":{\"data_type\":\"text\",\"value\":\"CN02AMP\"},\"EDITION\":{\"data_type\":\"numeric\",\"value\":2},\"EDITIONDATE\":{\"data_type\":\"date\",\"value\":\"2018/5/18\"},\"ERROR\":{\"data_type\":\"text\",\"value\":[\"0000\"]},\"ERRORCOUNT\":{\"data_type\":\"text\",\"value\":\"\"},\"OBJECTIVE\":{\"data_type\":\"text\"
		// ,\"value\":\"Decision Process Flow, Revision
		// 1.1\"},\"SIGNATURE\":{\"data_type\":\"text\",\"value\":\"AOC\"}},\"System\":{\"ReasonCode\":{\"data_type\":\"text\",\"value\":\"\"}}}}}}}},\"rusHeader\":{\"actionSegment\":{\"currentInterfaceName\":\"DPS\"},\"controlSegment\":{\"payloadCodePage\":\"UTF-8\",\"referenceNumber\":\"12345678901234500000\",\"requestFormat\":\"Y\",\"requestTimestamp\":\"2017-08-01
		// 18:12:11.1234
		// CST\",\"traceLevel\":\"JSON\"},\"headerSegment\":{\"businessUnit\":\"RBWM\",\"callType\":\"DECISION-ONLY\",\"countryCode\":\"HBHK\",\"requestID\":\"RBBSelerLoan\"}}}}";
		// ExecutorService executorService = Executors.newCachedThreadPool();
		// List<Future<String>> resultList = new ArrayList<Future<String>>();
		//
		// B b1 = new B(1000, "test1");
		// B b2 = new B(20000, "test2");
		// B b3 = new B(1500, "test3");
		// resultList.add(executorService.submit(b1));
		// resultList.add(executorService.submit(b2));
		// resultList.add(executorService.submit(b3));
		// executorService.shutdown();
		//
		// for (Future<String> future : resultList) {
		// try {
		// System.out.println(" result == == " + future.get());
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// } catch (ExecutionException e) {
		// e.printStackTrace();
		// }
		// }

	}

}
