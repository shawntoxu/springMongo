package com.test.app.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.when;
//
// import java.util.ArrayList;
// import java.util.List;
// import java.util.Map;
//
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import
/// org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.boot.test.mock.mockito.MockBean;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// @RunWith(SpringRunner.class)
// @SpringBootTest
// @AutoConfigureMockMvc
// @ActiveProfiles("local")
// @SuppressWarnings("unchecked")
// public class ApplicationServiceTest {
// @MockBean
// private ApplicationDao applicationDao;
// @Autowired
// private ApplicationService applicationService;
//
// public static String testSocialCreditCode_ok = "test-socialCreditCode";
//
// @Test
// public void testCreateApplication() {
// }
//
// @Test
// public void testGetApplication() {
// }
//
// @Test
// public void testGetApplicationBySocialCreditCode() throws Exception {
// LoanApplication lendinfo = getLendingInfo();
// when(this.applicationDao.queryApplicationByMutiValue(any(Map.class),
/// any(Map.class))).thenReturn(lendinfo);
// String result = this.applicationService
// .getApplicationBySocialCreditCodeAndTokenId(ApplicationServiceTest.testSocialCreditCode_ok,
/// "");
// assertEquals("Result will be phoneNumber", result, "150369874544");
// }
//
// @Test
// public void testGetApplicationBySocialCreditCode_NotFound() throws Exception
/// {
// when(this.applicationDao.queryApplicationByMutiValue(any(Map.class),
/// any(Map.class))).thenReturn(null);
// String result = this.applicationService
// .getApplicationBySocialCreditCodeAndTokenId(ApplicationServiceTest.testSocialCreditCode_ok,
/// "");
// assertEquals("Result will be null", result, null);
// }
//
// @Test
// public void testGetApplicationById() throws Exception {
// LoanApplication lendinfo = getLendingInfo();
// when(this.applicationDao.queryApplicationByMutiValue(any(Map.class),
/// any(Map.class))).thenReturn(lendinfo);
// LoanApplication result = this.applicationService.getApplicationById(true,
/// "referralId", "tokenid");
// assertEquals("Result will be not null", result, lendinfo);
//
// LoanApplication result2 = this.applicationService.getApplicationById(false,
/// "socialCreditCode");
// assertEquals("Result will be not null", result2, lendinfo);
// }
//
// @Test
// public void testGetApplicationById_NotFound() throws Exception {
// when(this.applicationDao.queryApplicationByMutiValue(any(Map.class),
/// any(Map.class))).thenReturn(null);
// LoanApplication result = this.applicationService.getApplicationById(true,
/// "referralId", "tokenid");
// assertEquals("Result will be null", result, null);
//
// LoanApplication result2 = this.applicationService.getApplicationById(false,
/// "socialCreditCode");
// assertEquals("Result will be null", result2, null);
// }
//
// public static LoanApplication getLendingInfo() {
// LoanApplication lendinfo = new LoanApplication();
// lendinfo.setTokenId("tokenId");
// lendinfo.setReferralId("referralId");
// lendinfo.setStatus(ApplicationStatus.STARTEDNOTUPLOAD);
// lendinfo.setEmailStatus(EmailStatus.INITIAL);
// lendinfo.setCountryCode("CN");
// lendinfo.setLastUpdateDate(CommonUtil.getCurrentDate("yyyyMMddHHmmss"));
//
// CompanyInfo c = new CompanyInfo();
// // c.setUnifiedSocialCreditCode("0964612317CCA");
// // c.setCompanyRegistrationNameCN("中国飞机制造厂");
// // c.setBusinessName("营业名称");
// // c.setRegistrationDate("2000-12-12");
// // c.setEstablishedCountry("成立国家");
// // c.setRegistrationCountry("注册国家");
// // c.setMainBusinessCountry("主营国家");
// // c.setOfficeMobileNumber("12345678911");
// // c.setEmailAddress(null);
// // c.setShareholders(null);
//
// lendinfo.setCompanyInfo(c);
// QianhaiInfo qianhaiInfo = new QianhaiInfo();
// qianhaiInfo.setEntName("中国飞机制造厂");
// qianhaiInfo.setEntType("有限责任公司");
// qianhaiInfo.setIndustryName("制造产业");
// // qianhaiInfo.setProvince("上海市");
// qianhaiInfo.setUserName("张玉良");
// // qianhaiInfo.setBusiScope1("飞机制造");
// qianhaiInfo.setRegNo("regno");
//
// Stakeholder sh = new Stakeholder();
// sh.setBankCardId("666688889995");
// sh.setCellphone("150369874544");
// sh.setNationality("中国");
// sh.setGuarantor(true);
// sh.setLegalRepresentative(true);
// sh.setPercentOfEquity("30%");
// sh.setIdCardNumber("6103696456134968797");
// sh.setRegistAddress("张三地址'");
// sh.setBirthday("1999-12-01");
// sh.setName("李四");
// sh.setValidityPeriodBegin("2010.09.09");
// sh.setValidityPeriodEnd("2040.09.09");
// sh.setIssuingAuthority("西安市公安局");
// sh.setIdCardType("中国居民身份证");
// sh.setIdCardFace("http://xxxxxxxxFacejpg");
// sh.setIdCardBack("http://xxxxxxxxBack.jpg");
//
// List<Stakeholder> shareHolders = new ArrayList<Stakeholder>();
// shareHolders.add(sh);
//
// lendinfo.setQianHaiInfo(qianhaiInfo);
// lendinfo.setStakeholder(shareHolders);
// lendinfo.setCompanyInfo(c);
//
// return lendinfo;
// }
// }
