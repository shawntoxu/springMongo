package com.test.app.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * <b> Configuration for Unit Test </b>
 * </p>
 */
@Configuration
@ComponentScan(basePackages = { "com.test.app" })
public class ConfigTest {

}
