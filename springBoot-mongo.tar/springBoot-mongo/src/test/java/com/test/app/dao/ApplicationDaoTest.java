package com.test.app.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.test.app.model.LoanApplication;

/**
 * @author Shawn.wang
 * @version Apr 28, 2018 10:38:12 AM
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("UAT")
public class ApplicationDaoTest {
	@SpyBean
	private MongoTemplate	template;

	@Autowired
	private ApplicationDao	applicationDao;

	@Test
	public void testSaveApplicationInfo() {
		Mockito.doNothing().when(this.template).save(any(Object.class));
		boolean result = this.applicationDao.saveApplicationInfo(new LoanApplication());
		assertEquals("Result will be true", result, true);
	}

	@Test
	public void testSaveApplicationInfo_SaveFaild() {
		Mockito.doThrow(new RuntimeException()).when(this.template).save(any(Object.class));
		boolean result2 = this.applicationDao.saveApplicationInfo(new LoanApplication());
		// assertEquals("Result will be false", result2, false);
	}

}
