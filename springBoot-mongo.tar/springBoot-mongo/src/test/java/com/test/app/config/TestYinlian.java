package com.test.app.config;

//
// import net.sf.json.JSONObject;
//
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import
// org.springframework.boot.context.properties.EnableConfigurationProperties;
// import
// org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpEntity;
// import org.springframework.http.HttpHeaders;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
/// **
// * @author Shawn.wang
// * @create Apr 23, 2018 10:35:10 AM
// */
//
// @RunWith(SpringRunner.class)
// @SpringBootTest
// @AutoConfigureMockMvc
// @ActiveProfiles("local")
// @EnableConfigurationProperties
// public class TestYinlian {
//
// @Autowired
// private RestTemplateUtil restTemplateUtil;
// @Autowired
// private TrustAllClientHttpRequestFactory CUPRequestFactory;
// @Autowired
// private TrustAllClientHttpRequestFactory noProxy;
//
// @Test
// public void test() throws Exception {
// // restTemplateTool
// CreditReportRequest re = new CreditReportRequest();
// re.setCertno("141126198103064718");
// re.setName("曹承");
// re.setBankCode("0317");
// re.setInstCode("0317");
// re.setCerttype("2");
// re.setPbocUserName("a");
// re.setPbocUserPassword("b");
// re.setQueryReason("03");
// re.setShenqingjianNo("");
//
// HttpHeaders headers = new HttpHeaders();
// headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
//
// final HttpEntity<JSONObject> httpEntity = new
// HttpEntity<JSONObject>(JSONObject.fromObject(re), headers);
// this.restTemplateUtil.setRequestFactory(this.CUPRequestFactory);
// final JSONObject responseEntity =
// this.restTemplateUtil.postForObject("http://172.26.204.93:58084/UIBS/personal/credit",
// httpEntity, JSONObject.class);
// System.out.println(responseEntity.toString());
// }
//
// // public static void main(final String[] args) {
// // // For Annotation
// // // ApplicationContext ctx = new
// // // AnnotationConfigApplicationContext(SpringMongoConfig.class);
// // ApplicationContext ctx = new
// // FileSystemXmlApplicationContext("resources/integration.xml");
// // // MongoOperations mongoTemplate = (MongoOperations)
// // // ctx.getBean("mongoTemplate");
// // RestTemplateTool restTemplateTool = (RestTemplateTool)
// // ctx.getBean("restTemplateTool");
// // CreditReportRequest re = new CreditReportRequest();
// // re.setCertno("141126198103064718");
// // re.setName("曹承");
// // re.setBankCode("0317");
// // re.setInstCode("0317");
// // re.setCerttype("2");
// // re.setPbocUserName("a");
// // re.setPbocUserPassword("b");
// // re.setQueryReason("03");
// // re.setShenqingjianNo("");
// //
// // HttpHeaders headers = new HttpHeaders();
// // headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
// //
// // final HttpEntity<JSONObject> httpEntity = new
// // HttpEntity<JSONObject>(JSONObject.fromObject(re), headers);
// //
// // final ResponseEntity<JSONObject> responseEntity =
// // restTemplateTool.exchange(
// // "http://172.26.204.93:58084/UIBS/personal/credit", HttpMethod.POST,
// // httpEntity, JSONObject.class);
// // System.out.println(responseEntity.toString());
// // }
// }
