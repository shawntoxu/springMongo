package com.test.app.controller;

//
// import static org.junit.Assert.assertEquals;
// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.when;
//
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
//
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import
/// org.springframework.boot.context.properties.EnableConfigurationProperties;
// import
/// org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.boot.test.mock.mockito.MockBean;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.test.web.servlet.MockMvc;
//
/// **
// * @author Shawn.wang
// * @version Apr 25, 2018 6:10:53 PM
// */
/// **
// * <p>
// * <b> TODO : Insert description of the class's responsibility/role. </b>
// * </p>
// */
// @RunWith(SpringRunner.class)
// @SpringBootTest
// @AutoConfigureMockMvc
// @ActiveProfiles("local")
// @EnableConfigurationProperties
// @SuppressWarnings({ "unchecked", "rawtypes" })
// public class ApplicationControllerTest {
// @Autowired
// private MockMvc mockMvc;
// @MockBean
// private SmsOtpService smsService;
// @MockBean
// ApplicationService applicationService;
// @MockBean
// private QianHaiService qianHaiService;
// @Autowired
// ApplicationController applicationController;
// @Autowired
// SmsOtpExperienceController smsExperienceController;
//
// public static String testSocialCreditCode_ok = "91440113724306988B";
// public static String testSocialCreditCode_falid = "T1440113724306988B";
// public static String test_phone = "8615026666666";
// public static String test_any_string = "teststring";
//
// @Test
// public void testCheckAppExists() throws Exception {
// when(this.applicationService.getApplicationBySocialCreditCodeAndTokenId(any(String.class),
/// any(String.class)))
// .thenReturn(ApplicationControllerTest.test_phone);
// BaseResponse<Map<String, Object>> response = this.applicationController
// .checkAppExists(ApplicationControllerTest.testSocialCreditCode_ok, "");
// assertEquals("Response Status should be 200", response.getRespCode(),
/// ResponseCode.Normal.getCode());
// Map<String, Object> responseBody = (Map<String, Object>)
/// response.getResponseBody();
// assertEquals("Response Status should be 200",
/// responseBody.get("alreadyExist"), true);
// }
//
// @Test
// public void testCheckAppExists_NotFound() throws Exception {
// when(this.applicationService.getApplicationBySocialCreditCodeAndTokenId(any(String.class),
/// any(String.class)))
// .thenReturn(null);
// BaseResponse<Map<String, Object>> response = this.applicationController
// .checkAppExists(ApplicationControllerTest.testSocialCreditCode_ok, "");
// assertEquals("Response Status should be 200", response.getRespCode(),
/// ResponseCode.Normal.getCode());
// Map<String, Object> responseBody = (Map<String, Object>)
/// response.getResponseBody();
// assertEquals("Response alreadyExist should be false",
/// responseBody.get("alreadyExist"), false);
// }
//
// public static String getEncryptedData() {
// Map<String, String> plaintextObj = new HashMap<String, String>();
// plaintextObj.put("phoneNumber", ApplicationControllerTest.test_phone);
// plaintextObj.put("REQUEST_ID", "REQUEST_ID");
// plaintextObj.put("GUID", "GUID");
// return DataSecurityUtil.encrypt(plaintextObj);
// }
//
// public static ApplicationHistoryReq getApplicationHistoryReq() {
// ApplicationHistoryReq applicationHistoryReq = new ApplicationHistoryReq();
// applicationHistoryReq.setEncryptedData(getEncryptedData());
// applicationHistoryReq.setEncryptedPhoneNumber(DataSecurityUtil.encrypt(ApplicationControllerTest.test_phone));
// applicationHistoryReq.setReferralId(ApplicationControllerTest.test_any_string);
// applicationHistoryReq.setUnifiedSocialCreditCode(ApplicationControllerTest.test_any_string);
// applicationHistoryReq.setVerifyCode(ApplicationControllerTest.test_any_string);
// return applicationHistoryReq;
// }
//
// @Test
// public void testGetAppHistoryInfo() throws Exception {
// ApplicationHistoryReq applicationHistoryReq = getApplicationHistoryReq();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(true);
// LoanApplication data = new LoanApplication();
// data.set_id(ApplicationControllerTest.test_any_string);
// when(this.applicationService.getApplicationById(any(Boolean.class),
/// any(String.class))).thenReturn(data);
// BaseResponse<Map<Object, Object>> response = this.applicationController
// .getAppHistoryInfo(applicationHistoryReq);
// assertEquals("Response Status should be 200 ", response.getRespCode(),
/// ResponseCode.Normal.getCode());
//
// Map<Object, Object> responseBody = (Map<Object, Object>)
/// response.getResponseBody();
// assertEquals("Response responseBody. _id will be null ",
/// responseBody.get("_id"), null);
// }
//
// @Test
// public void testGetAppHistoryInfo_verifySmsFaild() throws Exception {
// ApplicationHistoryReq applicationHistoryReq = getApplicationHistoryReq();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(false);
// BaseResponse<Map<Object, Object>> response = this.applicationController
// .getAppHistoryInfo(applicationHistoryReq);
// assertEquals("Response Status should be sms verify faild",
/// response.getRespCode(),
// ResponseCode.VERIFY_SMS_FAILED.getCode());
//
// }
//
// @Test
// public void testGetAppHistoryInfo_DBNotFound() throws Exception {
// ApplicationHistoryReq applicationHistoryReq = getApplicationHistoryReq();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(true);
// when(this.applicationService.getApplicationById(any(Boolean.class),
/// any(String.class))).thenReturn(null);
// BaseResponse<Map<Object, Object>> response = this.applicationController
// .getAppHistoryInfo(applicationHistoryReq);
// assertEquals("Response Status should be NOT_FOUND", response.getRespCode(),
/// ResponseCode.NOT_FOUND.getCode());
// }
//
// public static ApplicationCreateInfoReq getRequst() {
// ApplicationCreateInfoReq applicationCreateInfoReq = new
/// ApplicationCreateInfoReq();
// applicationCreateInfoReq.setEncryptedData(getEncryptedData());
// applicationCreateInfoReq.setMobileNumber(ApplicationControllerTest.test_phone);
// applicationCreateInfoReq.setIdCardNumber(ApplicationControllerTest.test_any_string);
// applicationCreateInfoReq.setReferralId(ApplicationControllerTest.test_any_string);
// applicationCreateInfoReq.setVerifyCode(ApplicationControllerTest.test_any_string);
// applicationCreateInfoReq.setUnifiedSocialCreditCode(ApplicationControllerTest.test_any_string);
// return applicationCreateInfoReq;
// }
//
// @Test
// public void testCreateApplication() throws Exception {
// ApplicationCreateInfoReq applicationCreateInfoReq = getRequst();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(true);
// LoanApplication loanApplication = getLendingInfo();
// when(this.applicationService.doBusinessCheck(applicationCreateInfoReq))
// .thenReturn(new Tuple(ResponseCode.Normal, loanApplication));
// when(this.applicationService.createApplication(any(LoanApplication.class))).thenReturn(true);
// BaseResponse<Object> response =
/// this.applicationController.createApplication(applicationCreateInfoReq);
// assertEquals("Response Status should be 200 ", response.getRespCode(),
/// ResponseCode.Normal.getCode());
// // System.out.println(JSONObject.fromObject(response).toString());
// }
//
// @Test
// public void testCreateApplication_CheckFaild() throws Exception {
// ApplicationCreateInfoReq applicationCreateInfoReq = getRequst();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(true);
// // test qianhai check faild
// when(this.applicationService.doBusinessCheck(applicationCreateInfoReq))
// .thenReturn(new Tuple(ResponseCode.Normal, null));
// BaseResponse<Object> response =
/// this.applicationController.createApplication(applicationCreateInfoReq);
// assertEquals("Response Status should be INFO_CHECK_FAILED ",
/// response.getRespCode(),
// ResponseCode.INFO_CHECK_FAILED.getCode());
// }
//
// @Test
// public void testCreateApplication_SaveDBFaild() throws Exception {
// ApplicationCreateInfoReq applicationCreateInfoReq = getRequst();
// when(this.smsService.verifySmsOtp(any(String.class), any(String.class),
/// any(String.class))).thenReturn(true);
// when(this.applicationService.doBusinessCheck(applicationCreateInfoReq))
// .thenReturn(new Tuple(ResponseCode.Normal, new LoanApplication()));
// // test save db faild
// when(this.applicationService.createApplication(new
/// LoanApplication())).thenReturn(false);
// BaseResponse<Object> response =
/// this.applicationController.createApplication(applicationCreateInfoReq);
// assertEquals("Response Status should be SYS_ERROR ", response.getRespCode(),
/// ResponseCode.SYS_ERROR.getCode());
// }
//
// public static LoanApplication getLendingInfo() {
// LoanApplication lendinfo = new LoanApplication();
// lendinfo.set_id("test");
// lendinfo.setTokenId("tokenId");
// lendinfo.setReferralId("referralId");
// lendinfo.setStatus(ApplicationStatus.STARTEDNOTUPLOAD);
// lendinfo.setEmailStatus(EmailStatus.INITIAL);
// lendinfo.setCountryCode("CN");
// lendinfo.setLastUpdateDate(CommonUtil.getCurrentDate("yyyyMMddHHmmss"));
//
// CompanyInfo c = new CompanyInfo();
// // c.setUnifiedSocialCreditCode("0964612317CCA");
// // c.setCompanyRegistrationNameCN("中国飞机制造厂");
// // c.setBusinessName("营业名称");
// // c.setRegistrationDate("2000-12-12");
// // c.setEstablishedCountry("成立国家");
// // c.setRegistrationCountry("注册国家");
// // c.setMainBusinessCountry("主营国家");
// // c.setOfficeMobileNumber("12345678911");
// // c.setEmailAddress(null);
// // c.setShareholders(null);
//
// lendinfo.setCompanyInfo(c);
// QianhaiInfo qianhaiInfo = new QianhaiInfo();
// qianhaiInfo.setEntName("中国飞机制造厂");
// qianhaiInfo.setEntType("有限责任公司");
// qianhaiInfo.setIndustryName("制造产业");
// // qianhaiInfo.setProvince("上海市");
// qianhaiInfo.setUserName("张玉良");
// // qianhaiInfo.setBusiScope1("飞机制造");
// qianhaiInfo.setRegNo("regno");
//
// Stakeholder sh = new Stakeholder();
// sh.setBankCardId("666688889995");
// sh.setCellphone("150369874544");
// sh.setNationality("中国");
// sh.setGuarantor(true);
// sh.setLegalRepresentative(true);
// sh.setPercentOfEquity("30%");
// sh.setIdCardNumber("6103696456134968797");
// sh.setRegistAddress("张三地址'");
// sh.setBirthday("1999-12-01");
// sh.setName("李四");
// sh.setValidityPeriodBegin("2010.09.09");
// sh.setValidityPeriodEnd("2040.09.09");
// sh.setIssuingAuthority("西安市公安局");
// sh.setIdCardType("中国居民身份证");
// sh.setIdCardFace("http://xxxxxxxxFacejpg");
// sh.setIdCardBack("http://xxxxxxxxBack.jpg");
//
// List<Stakeholder> shareHolders = new ArrayList<Stakeholder>();
// shareHolders.add(sh);
//
// lendinfo.setQianHaiInfo(qianhaiInfo);
// lendinfo.setStakeholder(shareHolders);
// lendinfo.setCompanyInfo(c);
//
// return lendinfo;
// }
// }
